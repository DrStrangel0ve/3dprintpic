#!/usr/bin/env bash
set -euo pipefail

ARCHIVE_PATH="${1:-/content/modelnet10_heldout1_hunyuan3d_2mv_octants8_smoke_colab_inputs.tar.gz}"
EXTRACT_ROOT="${EXTRACT_ROOT:-/content/3dprintpic_colab_inputs/modelnet10_heldout1_hunyuan3d_2mv_octants8_smoke}"
REPO_DIR="${REPO_DIR:-/content/3dprintpic}"
REPO_REMOTE="${REPO_REMOTE:-https://github.com/DrStrangel0ve/3dprintpic.git}"
REPO_REF="${REPO_REF:-8de0bc749da24ec3b2c018ff6b37d391bbc763b1}"

RUN_NAME=g4_stl_first_hunyuan3d_2mv_octants8_s40_n1_s5_r256
RUN_LOG="${RUN_LOG:-/content/3dprintpic_colab_inputs/modelnet10_heldout1_hunyuan3d_2mv_octants8_smoke/run_colab_eval.log}"
OUTPUT_ROOT="${OUTPUT_ROOT:-$REPO_DIR/backend/output/completion-benchmark/colab_g4/$RUN_NAME}"
RESULTS_SUMMARY="${RESULTS_SUMMARY:-/content/3dprintpic_colab_inputs/modelnet10_heldout1_hunyuan3d_2mv_octants8_smoke/results_summary.json}"
RESULTS_ARCHIVE="${RESULTS_ARCHIVE:-/content/g4_stl_first_hunyuan3d_2mv_octants8_s40_n1_s5_r256_results.tar.gz}"
STL_INGEST_DIR="${STL_INGEST_DIR:-/content/g4_stl_first_hunyuan3d_2mv_octants8_s40_n1_s5_r256_stl_first_ingest}"
STL_INGEST_JSON="${STL_INGEST_JSON:-/content/g4_stl_first_hunyuan3d_2mv_octants8_s40_n1_s5_r256_stl_first_ingest/stl_first_ingest_report.json}"
STL_INGEST_MD="${STL_INGEST_MD:-/content/g4_stl_first_hunyuan3d_2mv_octants8_s40_n1_s5_r256_stl_first_ingest/stl_first_ingest_report.md}"
MANIFEST_PATH=/content/3dprintpic_colab_inputs/modelnet10_heldout1_hunyuan3d_2mv_octants8_smoke/inputs/manifest.jsonl
LORA_PATH=''
LORA_ADAPTER_PATH=''
LORA_REPORT_PATH=''
GPU_PREFLIGHT_PATH=/content/3dprintpic_colab_inputs/modelnet10_heldout1_hunyuan3d_2mv_octants8_smoke/gpu_preflight.json
PREFLIGHT_PATH=/content/3dprintpic_colab_inputs/modelnet10_heldout1_hunyuan3d_2mv_octants8_smoke/launch_preflight.json
TRELLIS2_PREFLIGHT_PATH=/content/3dprintpic_colab_inputs/modelnet10_heldout1_hunyuan3d_2mv_octants8_smoke/trellis2_provider_preflight.json
HUNYUAN3D_2MV_PREFLIGHT_PATH=/content/3dprintpic_colab_inputs/modelnet10_heldout1_hunyuan3d_2mv_octants8_smoke/hunyuan3d_2mv_provider_preflight.json
COLAB_REQUIRE_GPU_NAME_REGEX="${COLAB_REQUIRE_GPU_NAME_REGEX:-}"
if [[ -z "$COLAB_REQUIRE_GPU_NAME_REGEX" ]]; then
  COLAB_REQUIRE_GPU_NAME_REGEX='RTX PRO 6000|Blackwell|G4'
fi
COLAB_MIN_GPU_MEMORY_GB="${COLAB_MIN_GPU_MEMORY_GB:-}"
if [[ -z "$COLAB_MIN_GPU_MEMORY_GB" ]]; then
  COLAB_MIN_GPU_MEMORY_GB=80.0
fi
export ARCHIVE_PATH EXTRACT_ROOT REPO_DIR REPO_REMOTE REPO_REF RUN_NAME RUN_LOG OUTPUT_ROOT RESULTS_SUMMARY RESULTS_ARCHIVE STL_INGEST_DIR STL_INGEST_JSON STL_INGEST_MD MANIFEST_PATH LORA_PATH LORA_ADAPTER_PATH LORA_REPORT_PATH GPU_PREFLIGHT_PATH PREFLIGHT_PATH TRELLIS2_PREFLIGHT_PATH HUNYUAN3D_2MV_PREFLIGHT_PATH COLAB_REQUIRE_GPU_NAME_REGEX COLAB_MIN_GPU_MEMORY_GB
mkdir -p "$EXTRACT_ROOT" "$(dirname "$RUN_LOG")" "$(dirname "$RESULTS_SUMMARY")" "$(dirname "$RESULTS_ARCHIVE")" "$STL_INGEST_DIR"
set +e
(
set -euo pipefail
export PYTHONUNBUFFERED="${PYTHONUNBUFFERED:-1}"
export PYTORCH_CUDA_ALLOC_CONF="${PYTORCH_CUDA_ALLOC_CONF:-expandable_segments:True}"
export CUDA_MODULE_LOADING="${CUDA_MODULE_LOADING:-LAZY}"
export MALLOC_ARENA_MAX="${MALLOC_ARENA_MAX:-2}"
python - <<'PY' | tee "$GPU_PREFLIGHT_PATH"
import json, os, re, shutil, subprocess

required_name = os.environ.get('COLAB_REQUIRE_GPU_NAME_REGEX', '').strip()
min_memory_raw = os.environ.get('COLAB_MIN_GPU_MEMORY_GB', '').strip()
min_memory_gb = None
errors = []
if min_memory_raw:
    try:
        min_memory_gb = float(min_memory_raw)
    except ValueError:
        errors.append(f'invalid COLAB_MIN_GPU_MEMORY_GB={min_memory_raw!r}')
    else:
        if min_memory_gb < 0:
            errors.append(f'COLAB_MIN_GPU_MEMORY_GB must be non-negative, got {min_memory_gb}')

query_error = ''
gpus = []
if shutil.which('nvidia-smi'):
    try:
        output = subprocess.check_output(
            [
                'nvidia-smi',
                '--query-gpu=name,memory.total',
                '--format=csv,noheader,nounits',
            ],
            text=True,
            stderr=subprocess.STDOUT,
        )
    except subprocess.CalledProcessError as exc:
        query_error = exc.output.strip() or f'nvidia-smi exited with {exc.returncode}'
    else:
        for line in output.splitlines():
            line = line.strip()
            if not line:
                continue
            name, _, memory_text = line.partition(',')
            name = name.strip()
            memory_text = memory_text.strip()
            memory_mib = None
            if memory_text:
                try:
                    memory_mib = float(memory_text)
                except ValueError:
                    pass
            gpu = {'index': len(gpus), 'name': name, 'memory_total_mib': memory_mib}
            if memory_mib is not None:
                gpu['memory_total_gb'] = memory_mib / 1024.0
            gpus.append(gpu)
else:
    query_error = 'nvidia-smi not found'

eligible = list(gpus)
if required_name:
    try:
        pattern = re.compile(required_name, re.IGNORECASE)
    except re.error as exc:
        errors.append(f'invalid COLAB_REQUIRE_GPU_NAME_REGEX={required_name!r}: {exc}')
        eligible = []
    else:
        eligible = [gpu for gpu in eligible if pattern.search(gpu.get('name') or '')]
if min_memory_gb is not None:
    eligible = [gpu for gpu in eligible if (gpu.get('memory_total_gb') or 0.0) >= min_memory_gb]

guard_requested = bool(required_name or min_memory_raw)
if guard_requested:
    if query_error:
        errors.append(query_error)
    elif not gpus:
        errors.append('no NVIDIA GPUs reported by nvidia-smi')
    elif not eligible:
        seen = ', '.join(
            f"{gpu.get('name') or 'unknown'} ({gpu.get('memory_total_gb', 0.0):.1f} GB)"
            for gpu in gpus
        )
        errors.append(
            'no GPU satisfied COLAB_REQUIRE_GPU_NAME_REGEX='
            f'{required_name!r} and COLAB_MIN_GPU_MEMORY_GB={min_memory_raw!r}; saw {seen}'
        )

payload = {
    'ok': not errors,
    'guard_requested': guard_requested,
    'requirements': {
        'name_regex': required_name,
        'min_memory_gb': min_memory_gb,
    },
    'cuda_visible_devices': os.environ.get('CUDA_VISIBLE_DEVICES', ''),
    'nvidia_smi_available': bool(shutil.which('nvidia-smi')),
    'nvidia_smi_error': query_error,
    'gpus': gpus,
    'eligible_gpus': eligible,
    'errors': errors,
}
print(json.dumps(payload, indent=2, sort_keys=True))
if errors:
    raise SystemExit('Colab GPU preflight failed: ' + '; '.join(errors))
PY
if [[ -n "${EXPECTED_SHA256:-}" ]]; then
  actual_sha="$(sha256sum "$ARCHIVE_PATH" | awk '{print $1}')"
  if [[ "$actual_sha" != "$EXPECTED_SHA256" ]]; then
    echo "archive sha256 mismatch: expected $EXPECTED_SHA256 got $actual_sha" >&2
    exit 2
  fi
fi
tar -xzf "$ARCHIVE_PATH" -C "$EXTRACT_ROOT"
test -s "$MANIFEST_PATH"
if [[ -n "$LORA_PATH" ]]; then
  test -s "$LORA_ADAPTER_PATH"
  test -s "$LORA_REPORT_PATH"
fi
manifest_rows="$(python - <<'PY'
import os, pathlib
manifest = pathlib.Path(os.environ['MANIFEST_PATH'])
print(sum(1 for line in manifest.read_text().splitlines() if line.strip()))
PY
)"
if [[ "$manifest_rows" -lt 1 ]]; then
  echo "rewritten manifest has no rows" >&2
  exit 2
fi
if [[ ! -d "$REPO_DIR/.git" ]]; then
  rm -rf "$REPO_DIR"
  git clone --filter=blob:none "$REPO_REMOTE" "$REPO_DIR"
fi
cd "$REPO_DIR"
git fetch "$REPO_REMOTE" "$REPO_REF"
git reset --hard FETCH_HEAD
resolved_commit="$(git rev-parse HEAD)"
if [[ "${COLAB_SKIP_BACKEND_INSTALL:-0}" == "1" ]]; then
  echo "Skipping backend pip install because COLAB_SKIP_BACKEND_INSTALL=1"
else
  python -m pip install -U pip
  if [[ -f backend/requirements-cuda.txt ]]; then
    python -m pip install -r backend/requirements-cuda.txt
  else
    python -m pip install -r backend/requirements.txt
  fi
fi
HUNYUAN3D_2MV_DIR="${HUNYUAN3D_2MV_DIR:-/content/Hunyuan3D-2}"
HUNYUAN3D_2MV_VENV="${HUNYUAN3D_2MV_VENV:-/content/hunyuan3d-2mv-venv}"
HUNYUAN3D_2MV_REF="${HUNYUAN3D_2MV_REF:-f8db63096c8282cb27354314d896feba5ba6ff8a}"
HUNYUAN3D_2MV_MODEL_ID="${HUNYUAN3D_2MV_MODEL_ID:-tencent/Hunyuan3D-2mv}"
HUNYUAN3D_2MV_MODEL_REVISION="${HUNYUAN3D_2MV_MODEL_REVISION:-3a761b539b29fe4ff64714813aa9560fd66f5de0}"
HUNYUAN3D_2MV_SUBFOLDER="${HUNYUAN3D_2MV_SUBFOLDER:-hunyuan3d-dit-v2-mv}"
export HUNYUAN3D_2MV_DIR HUNYUAN3D_2MV_VENV HUNYUAN3D_2MV_REF HUNYUAN3D_2MV_MODEL_ID HUNYUAN3D_2MV_MODEL_REVISION HUNYUAN3D_2MV_SUBFOLDER
if [[ ! -d "$HUNYUAN3D_2MV_DIR/.git" ]]; then
  rm -rf "$HUNYUAN3D_2MV_DIR"
  git clone --filter=blob:none https://github.com/Tencent-Hunyuan/Hunyuan3D-2 "$HUNYUAN3D_2MV_DIR"
fi
git -C "$HUNYUAN3D_2MV_DIR" fetch --filter=blob:none origin "$HUNYUAN3D_2MV_REF" || git -C "$HUNYUAN3D_2MV_DIR" fetch --filter=blob:none origin main
git -C "$HUNYUAN3D_2MV_DIR" checkout --detach "$HUNYUAN3D_2MV_REF"
git -C "$HUNYUAN3D_2MV_DIR" reset --hard "$HUNYUAN3D_2MV_REF"
test "$(git -C "$HUNYUAN3D_2MV_DIR" rev-parse HEAD)" = "$HUNYUAN3D_2MV_REF"
python -m pip install -q virtualenv
if [[ ! -x "$HUNYUAN3D_2MV_VENV/bin/python" ]]; then
  python -m virtualenv --system-site-packages "$HUNYUAN3D_2MV_VENV"
fi
HUNYUAN3D_2MV_PYTHON="$HUNYUAN3D_2MV_VENV/bin/python"
export HUNYUAN3D_2MV_PYTHON
export PYTHONPATH="$HUNYUAN3D_2MV_DIR:${PYTHONPATH:-}"
if ! "$HUNYUAN3D_2MV_PYTHON" - <<'PY'
import importlib
from importlib.metadata import version
for name in ('torch', 'torchvision', 'diffusers', 'transformers', 'accelerate', 'einops', 'cv2', 'omegaconf', 'trimesh', 'pymeshlab', 'skimage', 'safetensors', 'hy3dgen.shapegen'):
    importlib.import_module(name)
if not version('transformers').startswith('4.49.'):
    raise SystemExit(1)
PY
then
  "$HUNYUAN3D_2MV_PYTHON" -m pip install -U pip setuptools wheel
  "$HUNYUAN3D_2MV_PYTHON" -m pip install transformers==4.49.0 diffusers==0.32.2 accelerate==1.4.0 huggingface-hub==0.30.2 safetensors==0.5.3 einops==0.8.1 omegaconf==2.3.0 opencv-python-headless==4.11.0.86 tqdm==4.67.1 PyYAML==6.0.2 trimesh==4.12.2 pymeshlab==2025.7.post1 scikit-image==0.25.2
fi
"$HUNYUAN3D_2MV_PYTHON" - <<'PY'
import json
import shutil
import torch
import torchvision
from hy3dgen.shapegen import Hunyuan3DDiTFlowMatchingPipeline
if not torch.cuda.is_available():
    raise SystemExit('Hunyuan3D-2mv setup requires CUDA')
capability = torch.cuda.get_device_capability(0)
architectures = torch.cuda.get_arch_list()
expected_arch = f'sm_{capability[0]}{capability[1]}'
if expected_arch not in architectures:
    raise SystemExit(f'Torch wheel lacks {expected_arch}: {architectures}')
value = (torch.ones((256, 256), device='cuda') @ torch.ones((256, 256), device='cuda')).sum().item()
free_gib = shutil.disk_usage('/content').free / (1024 ** 3)
if free_gib < 8:
    raise SystemExit(f'Hunyuan3D-2mv setup needs at least 8 GiB free disk, got {free_gib:.1f}')
props = torch.cuda.get_device_properties(0)
print(json.dumps({
    'event': 'hunyuan3d_2mv_backend_ready',
    'pipeline_class': Hunyuan3DDiTFlowMatchingPipeline.__name__,
    'torch_version': torch.__version__,
    'torchvision_version': torchvision.__version__,
    'cuda_version': torch.version.cuda,
    'gpu': props.name,
    'capability': list(capability),
    'cuda_architectures': architectures,
    'cuda_smoke_value': value,
    'free_disk_gib': free_gib,
}, sort_keys=True))
PY
echo "Hunyuan3D-2mv setup checkpoint: provider imports and CUDA kernel ready"
HUNYUAN3D_2MV_PREFLIGHT_COMMAND="$HUNYUAN3D_2MV_PYTHON -m backend.benchmark.run_image_to_mesh_provider --provider hunyuan3d-2mv --provider-dir $HUNYUAN3D_2MV_DIR --provider-python $HUNYUAN3D_2MV_PYTHON --input-image '{input_image}' --input-bundle '{input_bundle}' --output-mesh '{output_mesh}' --hunyuan3d-2mv-model-path $HUNYUAN3D_2MV_MODEL_ID --hunyuan3d-2mv-model-revision $HUNYUAN3D_2MV_MODEL_REVISION --hunyuan3d-2mv-subfolder $HUNYUAN3D_2MV_SUBFOLDER"
"$HUNYUAN3D_2MV_PYTHON" -m backend.benchmark.preflight_image_to_mesh_providers --command "$HUNYUAN3D_2MV_PREFLIGHT_COMMAND" --output "${HUNYUAN3D_2MV_PREFLIGHT_PATH:-/tmp/hunyuan3d_2mv_provider_preflight.json}" --require-runnable
echo "Hunyuan3D-2mv setup checkpoint: provider preflight passed"
if [[ "${HUNYUAN3D_2MV_PREFETCH:-1}" == "1" ]]; then
  "$HUNYUAN3D_2MV_PYTHON" -m backend.benchmark.run_image_to_mesh_provider --provider hunyuan3d-2mv --provider-dir "$HUNYUAN3D_2MV_DIR" --hunyuan3d-2mv-model-path "$HUNYUAN3D_2MV_MODEL_ID" --hunyuan3d-2mv-model-revision "$HUNYUAN3D_2MV_MODEL_REVISION" --hunyuan3d-2mv-subfolder "$HUNYUAN3D_2MV_SUBFOLDER" --timeout 3600 --prefetch-only
  echo "Hunyuan3D-2mv setup checkpoint: pinned model prefetched"
fi
python - <<'PY' > "$PREFLIGHT_PATH"
import json, os, pathlib, subprocess
archive = pathlib.Path(os.environ['ARCHIVE_PATH'])
manifest = pathlib.Path(os.environ['MANIFEST_PATH'])
payload = {
    'archive': str(archive),
    'archive_sha256': subprocess.check_output(['sha256sum', str(archive)], text=True).split()[0],
    'repo_dir': os.environ['REPO_DIR'],
    'repo_remote': os.environ['REPO_REMOTE'],
    'repo_ref': os.environ['REPO_REF'],
    'resolved_commit': subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip(),
    'extract_root': os.environ['EXTRACT_ROOT'],
    'gpu_preflight': os.environ['GPU_PREFLIGHT_PATH'],
    'trellis2_provider_preflight': os.environ['TRELLIS2_PREFLIGHT_PATH'],
    'hunyuan3d_2mv_provider_preflight': os.environ['HUNYUAN3D_2MV_PREFLIGHT_PATH'],
    'manifest': str(manifest),
    'manifest_rows': sum(1 for line in manifest.read_text().splitlines() if line.strip()),
}
if os.environ.get('LORA_PATH'):
    payload['lora_path'] = os.environ['LORA_PATH']
    payload['lora_adapter'] = os.environ['LORA_ADAPTER_PATH']
print(json.dumps(payload, indent=2, sort_keys=True))
PY
if [[ "${COLAB_PROVIDER_SETUP_ONLY:-0}" == "1" || "${HUNYUAN3D_SETUP_ONLY:-0}" == "1" || "${HUNYUAN3D_2MV_SETUP_ONLY:-0}" == "1" || "${TRIPOSR_SETUP_ONLY:-0}" == "1" || "${TRIPOSG_SETUP_ONLY:-0}" == "1" || "${PIXAL3D_SETUP_ONLY:-0}" == "1" || "${TRELLIS2_SETUP_ONLY:-0}" == "1" ]]; then
  echo "Provider setup only requested; skipping benchmark stages"
  exit 0
fi
python -u -m backend.benchmark.colab_g4_orchestrator --use-current-repo --run-name g4_stl_first_hunyuan3d_2mv_octants8_s40_n1_s5_r256 --stage cache --stage eval --stage combine --manifest /content/3dprintpic_colab_inputs/modelnet10_heldout1_hunyuan3d_2mv_octants8_smoke/inputs/manifest.jsonl --eval-limit 1 --score-profile stl-quality --cache-download-mode snapshot --cache-max-workers 8 --min-paired-n 1 --max-method-failures 1 --modern-config backend/benchmark/experiment_configs/modelnet10_60_balanced_stl_quality_hunyuan3d_2mv_s40_n1_smoke.json --skip-cache --depth-provider depth-anything-v2 --depth-model depth-anything/Depth-Anything-V2-Small-hf --stl-target-dimension 96 --candidate-method hunyuan3d_2mv_cardinal4_s5_r256_repaired_stl_inferred_bbox_direct_mesh --current-method mirror --eval-start 0 --require-image-to-mesh-providers --allow-missing-split-audit --contact-sheet-methods masked,mirror,biharmonic,source_mesh_oracle,hunyuan3d_2mv_cardinal4_s5_r256_raw_direct_mesh,hunyuan3d_2mv_cardinal4_s5_r256_repaired_stl_inferred_bbox_direct_mesh --contact-sheet-max-samples 1
) 2>&1 | tee "$RUN_LOG"
run_status="${PIPESTATUS[0]}"
set -e
export RUN_STATUS="$run_status"
python - <<'PY'
from datetime import datetime, timezone
import csv, json, os, pathlib, subprocess, sys, tarfile

def add_if_exists(tar: tarfile.TarFile, path: pathlib.Path, arcname: str) -> None:
    if path.exists():
        tar.add(path, arcname=arcname)

def read_csv_rows(path: pathlib.Path) -> list[dict]:
    if not path.exists():
        return []
    with path.open(newline='', encoding='utf-8') as csv_file:
        return list(csv.DictReader(csv_file))

def read_json_object(path: pathlib.Path) -> dict:
    if not path.exists():
        return {}
    try:
        return json.loads(path.read_text(encoding='utf-8'))
    except Exception as exc:
        return {'read_error': f'{type(exc).__name__}: {exc}'}

def summarize_gpu_preflight(path: pathlib.Path) -> dict:
    data = read_json_object(path)
    summary = {'exists': path.exists(), 'path': str(path)}
    if not data:
        return summary
    if data.get('read_error'):
        summary['read_error'] = data.get('read_error')
        return summary
    summary.update(
        {
            'ok': data.get('ok'),
            'guard_requested': data.get('guard_requested'),
            'requirements': data.get('requirements') or {},
            'nvidia_smi_available': data.get('nvidia_smi_available'),
            'nvidia_smi_error': data.get('nvidia_smi_error', ''),
            'errors': data.get('errors') or [],
            'gpus': data.get('gpus') or [],
            'eligible_gpus': data.get('eligible_gpus') or [],
        }
    )
    return summary

def compact_methods(rows: list[dict]) -> list[dict]:
    keys = [
        'method', 'base_method', 'stl_mode', 'n', 'attempted_n', 'success_rate',
        'error_count', 'logged_failure_count', 'rank_score',
        'mesh_surface_chamfer_l1_median', 'mesh_surface_hausdorff95_median',
        'provider_inference_runtime_seconds_median', 'provider_invocation_runtime_seconds_median',
        'direct_mesh_command_runtime_seconds_median', 'repair_runtime_seconds_median',
        'mesh_postprocess_runtime_seconds_median', 'provider_peak_cuda_vram_gib_median',
        'raw_mesh_volume_fill_ratio_median', 'stl_volume_fill_ratio_median',
        'repair_volume_fill_ratio_relative_change_median',
        'silhouette_iou_masked_median', 'stl_exists_median', 'stl_is_watertight_median',
        'stl_is_volume_median', 'stl_is_manifold_median', 'stl_positive_volume_median',
        'stl_single_component_median', 'stl_nonmanifold_edge_count_log1p_median',
        'stl_degenerate_face_ratio_median', 'stl_component_excess_log1p_median',
        'stl_bbox_aspect_ratio_median', 'stl_faces_per_normalized_bbox_volume_log1p_median',
        'stl_faces_per_bbox_volume_log1p_median',
    ]
    return [{key: row.get(key, '') for key in keys if key in row} for row in rows]

def summarize_benchmark_dir(path: pathlib.Path) -> dict:
    aggregate = path / 'aggregate_summary.csv'
    ranked = path / 'ranked_experiments.csv'
    selection = path / 'selection_decision.json'
    contact_sheet = path / 'artifact_contact_sheet.png'
    image_to_mesh_preflight = path / 'image_to_mesh_provider_preflight.json'
    aggregate_rows = read_csv_rows(aggregate)
    ranked_rows = read_csv_rows(ranked)
    selection_json = read_json_object(selection)
    image_to_mesh_preflight_json = read_json_object(image_to_mesh_preflight)
    digest = {
        'path': str(path),
        'aggregate_summary_exists': aggregate.exists(),
        'ranked_experiments_exists': ranked.exists(),
        'selection_decision_exists': selection.exists(),
        'contact_sheet_exists': contact_sheet.exists(),
        'image_to_mesh_provider_preflight_exists': image_to_mesh_preflight.exists(),
        'methods': compact_methods(ranked_rows or aggregate_rows),
    }
    if image_to_mesh_preflight_json:
        rows = image_to_mesh_preflight_json.get('rows') or []
        digest['image_to_mesh_provider_readiness'] = [
            {
                'provider': row.get('provider', ''),
                'readiness': row.get('readiness', ''),
                'runnable': row.get('runnable', False),
                'experiment_names': row.get('experiment_names', []),
                'setup_errors': row.get('setup_errors', []),
            }
            for row in rows
        ]
    if ranked_rows:
        top = ranked_rows[0]
        digest['top_method'] = top.get('method', '')
        digest['top_rank_score'] = top.get('rank_score', '')
    if selection_json:
        digest['decision'] = selection_json.get('decision', '')
        digest['candidate_method'] = selection_json.get('candidate_method', '')
        digest['failed_checks'] = [check.get('name', '') for check in selection_json.get('failed_checks', [])]
    return digest

def run_stl_ingest_report(output_root: pathlib.Path, ingest_dir: pathlib.Path, json_path: pathlib.Path, md_path: pathlib.Path, gpu_preflight_summary: dict) -> dict:
    log_path = ingest_dir / 'stl_first_ingest.log'
    result = {
        'status': 'skipped',
        'output_dir': str(ingest_dir),
        'json': str(json_path),
        'markdown': str(md_path),
        'log': str(log_path),
    }
    if os.environ.get('COLAB_PROVIDER_SETUP_ONLY') == '1' or os.environ.get('HUNYUAN3D_SETUP_ONLY') == '1' or os.environ.get('HUNYUAN3D_2MV_SETUP_ONLY') == '1' or os.environ.get('TRIPOSR_SETUP_ONLY') == '1' or os.environ.get('TRIPOSG_SETUP_ONLY') == '1' or os.environ.get('PIXAL3D_SETUP_ONLY') == '1' or os.environ.get('TRELLIS2_SETUP_ONLY') == '1':
        result['reason'] = 'provider_setup_only'
        return result
    if not output_root.exists():
        result['reason'] = 'gpu_preflight_failed' if gpu_preflight_summary.get('ok') is False else 'output_root_missing'
        if gpu_preflight_summary.get('errors'):
            result['gpu_preflight_errors'] = gpu_preflight_summary.get('errors')
        return result
    ingest_dir.mkdir(parents=True, exist_ok=True)
    cmd = [
        sys.executable,
        '-m',
        'backend.benchmark.ingest_stl_results',
        f"{os.environ['RUN_NAME']}={output_root}",
        '--output-dir',
        str(ingest_dir),
        '--output-json',
        str(json_path),
        '--output-md',
        str(md_path),
        '--score-profile',
        'stl-quality',
        '--score-mode',
        'baseline-delta',
        '--baseline-method',
        'masked',
    ]
    with log_path.open('w', encoding='utf-8') as log_file:
        completed = subprocess.run(cmd, cwd=os.environ['REPO_DIR'], stdout=log_file, stderr=subprocess.STDOUT, text=True, check=False)
    result['status'] = 'ok' if completed.returncode == 0 else 'failed'
    result['returncode'] = completed.returncode
    result['json_exists'] = json_path.exists()
    result['markdown_exists'] = md_path.exists()
    if json_path.exists():
        try:
            report = json.loads(json_path.read_text(encoding='utf-8'))
            runs = report.get('runs') or []
            if runs:
                decision = runs[0].get('architecture_replacement_decision') or {}
                result['architecture_replacement_decision'] = {
                    'decision': decision.get('decision', ''),
                    'recommended_method': decision.get('recommended_method', ''),
                    'recommended_stl_mode': decision.get('recommended_stl_mode', ''),
                    'score_delta_vs_depth_relief': decision.get('score_delta_vs_depth_relief'),
                    'depth_relief_baseline_method': (decision.get('depth_relief_baseline') or {}).get('method', ''),
                    'promotion_eligible_challenger_method': (decision.get('promotion_eligible_challenger') or {}).get('method', ''),
                    'score_leading_challenger_method': (decision.get('score_leading_challenger') or {}).get('method', ''),
                }
                result['run_count'] = len(runs)
        except Exception as exc:
            result['report_read_error'] = f'{type(exc).__name__}: {exc}'
    return result

output_root = pathlib.Path(os.environ['OUTPUT_ROOT'])
run_log = pathlib.Path(os.environ['RUN_LOG'])
gpu_preflight = pathlib.Path(os.environ['GPU_PREFLIGHT_PATH'])
preflight = pathlib.Path(os.environ['PREFLIGHT_PATH'])
trellis2_preflight = pathlib.Path(os.environ['TRELLIS2_PREFLIGHT_PATH'])
hunyuan3d_2mv_preflight = pathlib.Path(os.environ['HUNYUAN3D_2MV_PREFLIGHT_PATH'])
summary_path = pathlib.Path(os.environ['RESULTS_SUMMARY'])
archive_path = pathlib.Path(os.environ['RESULTS_ARCHIVE'])
stl_ingest_dir = pathlib.Path(os.environ['STL_INGEST_DIR'])
stl_ingest_json = pathlib.Path(os.environ['STL_INGEST_JSON'])
stl_ingest_md = pathlib.Path(os.environ['STL_INGEST_MD'])
run_status = int(os.environ['RUN_STATUS'])
gpu_preflight_summary = summarize_gpu_preflight(gpu_preflight)
trellis2_preflight_summary = read_json_object(trellis2_preflight)
trellis2_preflight_failed = any(not row.get('runnable') for row in trellis2_preflight_summary.get('rows', []))
hunyuan3d_2mv_preflight_expected = True
hunyuan3d_2mv_preflight_summary = read_json_object(hunyuan3d_2mv_preflight)
hunyuan3d_2mv_preflight_rows = hunyuan3d_2mv_preflight_summary.get('rows', [])
hunyuan3d_2mv_preflight_failed = hunyuan3d_2mv_preflight_expected and (not hunyuan3d_2mv_preflight_rows or any(not row.get('runnable') for row in hunyuan3d_2mv_preflight_rows))
orchestrator_result = output_root / 'orchestrator_result.json'
selection_decisions = sorted(output_root.glob('combined/*/selection_decision.json')) if output_root.exists() else []
eval_summaries = [summarize_benchmark_dir(path) for path in sorted(output_root.glob('experiments/*'))] if output_root.exists() else []
combined_summaries = [summarize_benchmark_dir(path) for path in sorted(output_root.glob('combined/*'))] if output_root.exists() else []
stl_ingest_report = run_stl_ingest_report(output_root, stl_ingest_dir, stl_ingest_json, stl_ingest_md, gpu_preflight_summary)
summary = {
    'generated_at': datetime.now(timezone.utc).isoformat(timespec='seconds'),
    'run_name': os.environ['RUN_NAME'],
    'run_status': run_status,
    'failure_stage': 'gpu_preflight' if run_status and gpu_preflight_summary.get('ok') is False else ('hunyuan3d_2mv_preflight' if run_status and hunyuan3d_2mv_preflight_failed else ('trellis2_preflight' if run_status and trellis2_preflight_failed else '')),
    'provider_setup_only': os.environ.get('COLAB_PROVIDER_SETUP_ONLY') == '1' or os.environ.get('HUNYUAN3D_SETUP_ONLY') == '1' or os.environ.get('HUNYUAN3D_2MV_SETUP_ONLY') == '1' or os.environ.get('TRIPOSR_SETUP_ONLY') == '1' or os.environ.get('TRIPOSG_SETUP_ONLY') == '1' or os.environ.get('PIXAL3D_SETUP_ONLY') == '1' or os.environ.get('TRELLIS2_SETUP_ONLY') == '1',
    'output_root': str(output_root),
    'output_root_exists': output_root.exists(),
    'run_log': str(run_log),
    'gpu_preflight': str(gpu_preflight),
    'gpu_preflight_summary': gpu_preflight_summary,
    'preflight': str(preflight),
    'trellis2_provider_preflight': str(trellis2_preflight),
    'trellis2_provider_preflight_summary': trellis2_preflight_summary,
    'hunyuan3d_2mv_provider_preflight': str(hunyuan3d_2mv_preflight),
    'hunyuan3d_2mv_provider_preflight_expected': hunyuan3d_2mv_preflight_expected,
    'hunyuan3d_2mv_provider_preflight_summary': hunyuan3d_2mv_preflight_summary,
    'results_archive': str(archive_path),
    'stl_first_ingest_report': stl_ingest_report,
    'orchestrator_result': str(orchestrator_result) if orchestrator_result.exists() else '',
    'selection_decisions': [str(path) for path in selection_decisions],
    'eval_summaries': eval_summaries,
    'combined_summaries': combined_summaries,
}
summary_path.write_text(json.dumps(summary, indent=2, sort_keys=True) + '\n', encoding='utf-8')
archive_path.parent.mkdir(parents=True, exist_ok=True)
with tarfile.open(archive_path, 'w:gz') as tar:
    add_if_exists(tar, gpu_preflight, 'gpu_preflight.json')
    add_if_exists(tar, preflight, 'launch_preflight.json')
    add_if_exists(tar, trellis2_preflight, 'trellis2_provider_preflight.json')
    add_if_exists(tar, hunyuan3d_2mv_preflight, 'hunyuan3d_2mv_provider_preflight.json')
    add_if_exists(tar, run_log, 'run_colab_eval.log')
    add_if_exists(tar, summary_path, 'results_summary.json')
    add_if_exists(tar, stl_ingest_json, 'stl_first_ingest_report.json')
    add_if_exists(tar, stl_ingest_md, 'stl_first_ingest_report.md')
    add_if_exists(tar, stl_ingest_dir / 'stl_first_ingest.log', 'stl_first_ingest.log')
    if output_root.exists():
        tar.add(output_root, arcname=f"output/{output_root.name}")
print(json.dumps(summary, indent=2, sort_keys=True))
PY
echo "Results archive: $RESULTS_ARCHIVE"
exit "$run_status"
