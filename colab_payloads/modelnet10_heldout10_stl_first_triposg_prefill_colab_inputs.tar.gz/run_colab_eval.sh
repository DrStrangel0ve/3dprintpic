#!/usr/bin/env bash
set -euo pipefail

ARCHIVE_PATH="${1:-/content/modelnet10_heldout10_stl_first_triposg_prefill_colab_inputs.tar.gz}"
EXTRACT_ROOT="${EXTRACT_ROOT:-/content/3dprintpic_colab_inputs/modelnet10_heldout10_stl_first_triposg_prefill}"
REPO_DIR="${REPO_DIR:-/content/3dprintpic}"
REPO_REMOTE="${REPO_REMOTE:-https://github.com/DrStrangel0ve/3dprintpic.git}"
REPO_REF="${REPO_REF:-codex/3d-completion-benchmark-g4}"

RUN_NAME=g4_stl_first_triposg_prefill_s40_n10
RUN_LOG="${RUN_LOG:-/content/3dprintpic_colab_inputs/modelnet10_heldout10_stl_first_triposg_prefill/run_colab_eval.log}"
OUTPUT_ROOT="${OUTPUT_ROOT:-$REPO_DIR/backend/output/completion-benchmark/colab_g4/$RUN_NAME}"
RESULTS_SUMMARY="${RESULTS_SUMMARY:-/content/3dprintpic_colab_inputs/modelnet10_heldout10_stl_first_triposg_prefill/results_summary.json}"
RESULTS_ARCHIVE="${RESULTS_ARCHIVE:-/content/g4_stl_first_triposg_prefill_s40_n10_results.tar.gz}"
MANIFEST_PATH=/content/3dprintpic_colab_inputs/modelnet10_heldout10_stl_first_triposg_prefill/inputs/manifest.jsonl
LORA_PATH=''
LORA_ADAPTER_PATH=''
LORA_REPORT_PATH=''
PREFLIGHT_PATH=/content/3dprintpic_colab_inputs/modelnet10_heldout10_stl_first_triposg_prefill/launch_preflight.json
export ARCHIVE_PATH EXTRACT_ROOT REPO_DIR REPO_REMOTE REPO_REF RUN_NAME RUN_LOG OUTPUT_ROOT RESULTS_SUMMARY RESULTS_ARCHIVE MANIFEST_PATH LORA_PATH LORA_ADAPTER_PATH LORA_REPORT_PATH PREFLIGHT_PATH
mkdir -p "$EXTRACT_ROOT" "$(dirname "$RUN_LOG")" "$(dirname "$RESULTS_SUMMARY")" "$(dirname "$RESULTS_ARCHIVE")"
set +e
(
set -euo pipefail
export PYTHONUNBUFFERED="${PYTHONUNBUFFERED:-1}"
export PYTORCH_CUDA_ALLOC_CONF="${PYTORCH_CUDA_ALLOC_CONF:-expandable_segments:True}"
export CUDA_MODULE_LOADING="${CUDA_MODULE_LOADING:-LAZY}"
export MALLOC_ARENA_MAX="${MALLOC_ARENA_MAX:-2}"
if [[ -n "${EXPECTED_SHA256:-}" ]]; then
  actual_sha="$(sha256sum "$ARCHIVE_PATH" | awk '{print $1}')"
  if [[ "$actual_sha" != "$EXPECTED_SHA256" ]]; then
    echo "archive sha256 mismatch: expected $EXPECTED_SHA256 got $actual_sha" >&2
    exit 2
  fi
fi
tar -xzf "$ARCHIVE_PATH" -C "$EXTRACT_ROOT"
test -s "$MANIFEST_PATH"
if [[ -n "$LORA_PATH" ]]; then
  test -s "$LORA_ADAPTER_PATH"
  test -s "$LORA_REPORT_PATH"
fi
manifest_rows="$(python - <<'PY'
import os, pathlib
manifest = pathlib.Path(os.environ['MANIFEST_PATH'])
print(sum(1 for line in manifest.read_text().splitlines() if line.strip()))
PY
)"
if [[ "$manifest_rows" -lt 1 ]]; then
  echo "rewritten manifest has no rows" >&2
  exit 2
fi
if [[ ! -d "$REPO_DIR/.git" ]]; then
  rm -rf "$REPO_DIR"
  git clone --filter=blob:none "$REPO_REMOTE" "$REPO_DIR"
fi
cd "$REPO_DIR"
git fetch "$REPO_REMOTE" "$REPO_REF"
git reset --hard FETCH_HEAD
resolved_commit="$(git rev-parse HEAD)"
if [[ "${COLAB_SKIP_BACKEND_INSTALL:-0}" == "1" ]]; then
  echo "Skipping backend pip install because COLAB_SKIP_BACKEND_INSTALL=1"
else
  python -m pip install -U pip
  if [[ -f backend/requirements-cuda.txt ]]; then
    python -m pip install -r backend/requirements-cuda.txt
  else
    python -m pip install -r backend/requirements.txt
  fi
fi
TRIPOSG_DIR="${TRIPOSG_DIR:-/content/TripoSG}"
TRIPOSG_VENV="${TRIPOSG_VENV:-/content/triposg-venv}"
TRIPOSG_REF="${TRIPOSG_REF:-fc5c40990181e2a756c4e0b1c2f4d6b5202faf8c}"
export TRIPOSG_DIR TRIPOSG_VENV TRIPOSG_REF
if [[ ! -d "$TRIPOSG_DIR/.git" ]]; then
  rm -rf "$TRIPOSG_DIR"
  git clone --filter=blob:none https://github.com/VAST-AI-Research/TripoSG "$TRIPOSG_DIR"
  git -C "$TRIPOSG_DIR" checkout "$TRIPOSG_REF"
else
  git -C "$TRIPOSG_DIR" fetch --filter=blob:none origin "$TRIPOSG_REF" || git -C "$TRIPOSG_DIR" fetch --filter=blob:none origin main
  git -C "$TRIPOSG_DIR" checkout "$TRIPOSG_REF"
fi
git -C "$TRIPOSG_DIR" reset --hard "$TRIPOSG_REF"
python - <<'PY'
import os
from pathlib import Path
root = Path(os.environ['TRIPOSG_DIR'])
inference_utils = root / 'triposg' / 'inference_utils.py'
text = inference_utils.read_text()
text = text.replace('from diso import DiffDMC\n', '')
needle = '        dmc = DiffDMC(dtype=torch.float32).to(grid_logits.device)\n'
replacement = '        from diso import DiffDMC\n        dmc = DiffDMC(dtype=torch.float32).to(grid_logits.device)\n'
if replacement not in text:
    text = text.replace(needle, replacement)
inference_utils.write_text(text)
script = root / 'scripts' / 'inference_triposg.py'
text = script.read_text()
needle = '        guidance_scale=guidance_scale,\n    ).samples[0]'
replacement = '        guidance_scale=guidance_scale,\n        use_flash_decoder=os.environ.get("TRIPOSG_USE_FLASH_DECODER", "0") == "1",\n    ).samples[0]'
if 'TRIPOSG_USE_FLASH_DECODER' not in text:
    text = text.replace(needle, replacement)
script.write_text(text)
print('TripoSG setup checkpoint: non-flash decoder patch applied')
PY
python -m pip install -q virtualenv
if [[ ! -x "$TRIPOSG_VENV/bin/python" ]]; then
  python -m virtualenv --system-site-packages "$TRIPOSG_VENV"
fi
export PYTHONPATH="$TRIPOSG_DIR:${PYTHONPATH:-}"
if ! "$TRIPOSG_VENV/bin/python" - <<'PY'
import os
import importlib
missing = []
required = ['torch', 'diffusers', 'transformers', 'trimesh', 'triposg.pipelines.pipeline_triposg']
if os.environ.get('TRIPOSG_INSTALL_DISO') == '1' or os.environ.get('TRIPOSG_USE_FLASH_DECODER') == '1':
    required.append('diso')
for name in required:
    try:
        importlib.import_module(name)
    except Exception as exc:
        missing.append(f'{name} ({type(exc).__name__}: {exc})')
if missing:
    print('missing TripoSG Python deps: ' + ', '.join(missing))
    raise SystemExit(1)
PY
then
  "$TRIPOSG_VENV/bin/python" -m pip install -U pip setuptools wheel
  python - <<'PY'
import os
from pathlib import Path
source = Path(os.environ['TRIPOSG_DIR']) / 'requirements.txt'
target = Path('/tmp/triposg_requirements_colab.txt')
skip_prefixes = ('numpy', 'torch', 'torchvision', 'torchaudio')
lines = []
if source.exists():
    for raw in source.read_text().splitlines():
        line = raw.strip()
        if not line or line.startswith('#'):
            continue
        lowered = line.lower()
        if os.environ.get('TRIPOSG_INSTALL_DISO') != '1' and (lowered == 'diso' or lowered.startswith('diso' + ' ')):
            continue
        if any(lowered == prefix or lowered.startswith(prefix + spec) for prefix in skip_prefixes for spec in ('=', '<', '>', '~', ' ')):
            continue
        lines.append(line)
target.write_text('\n'.join(lines) + ('\n' if lines else ''))
print(target)
PY
  "$TRIPOSG_VENV/bin/python" -m pip install numpy==2.0.2 trimesh==4.12.2 Pillow==10.1.0 huggingface-hub imageio packaging ninja
  if [[ "${TRIPOSG_INSTALL_DISO:-0}" == "1" || "${TRIPOSG_USE_FLASH_DECODER:-0}" == "1" ]]; then
    export CUDA_HOME="${CUDA_HOME:-/usr/local/cuda}"
    export PATH="$CUDA_HOME/bin:$PATH"
    export LD_LIBRARY_PATH="$CUDA_HOME/lib64:${LD_LIBRARY_PATH:-}"
    export FORCE_CUDA="${FORCE_CUDA:-1}"
    export TORCH_CUDA_ARCH_LIST="${TORCH_CUDA_ARCH_LIST:-12.0}"
    export MAX_JOBS="${MAX_JOBS:-1}"
    export NVCC_FLAGS="${NVCC_FLAGS:--O3 --threads 1}"
    "$TRIPOSG_VENV/bin/python" -m pip install -v --no-cache-dir --no-build-isolation --no-binary=:all: diso==0.1.4
  fi
  if [[ -s /tmp/triposg_requirements_colab.txt ]]; then
    "$TRIPOSG_VENV/bin/python" -m pip install -r /tmp/triposg_requirements_colab.txt
  fi
  "$TRIPOSG_VENV/bin/python" - <<'PY'
import os
import importlib
required = ['torch', 'diffusers', 'transformers', 'trimesh', 'triposg.pipelines.pipeline_triposg']
if os.environ.get('TRIPOSG_INSTALL_DISO') == '1' or os.environ.get('TRIPOSG_USE_FLASH_DECODER') == '1':
    required.append('diso')
for name in required:
    importlib.import_module(name)
PY
fi
echo "TripoSG setup checkpoint: Python deps importable"
(cd "$TRIPOSG_DIR" && "$TRIPOSG_VENV/bin/python" -m scripts.inference_triposg --help >/tmp/triposg_inference_help.txt)
echo "TripoSG setup checkpoint: CLI imports ok"
if [[ "${TRIPOSG_PREFETCH:-0}" == "1" ]]; then
  "$TRIPOSG_VENV/bin/python" - <<'PY'
import torch
from huggingface_hub import snapshot_download
if not torch.cuda.is_available():
    raise SystemExit('TripoSG prefetch requires CUDA, but torch.cuda.is_available() is false')
props = torch.cuda.get_device_properties(0)
total_gb = props.total_memory / (1024 ** 3)
print(f'TripoSG CUDA device: {props.name}, VRAM={total_gb:.1f} GB')
if total_gb < 8:
    raise SystemExit(f'TripoSG needs at least about 8 GB VRAM, got {total_gb:.1f} GB')
for repo_id in ('VAST-AI/TripoSG', 'briaai/RMBG-1.4'):
    path = snapshot_download(repo_id=repo_id)
    print(f'TripoSG prefetched {repo_id}: {path}')
PY
  echo "TripoSG setup checkpoint: weights prefetched"
fi
python - <<'PY' > "$PREFLIGHT_PATH"
import json, os, pathlib, subprocess
archive = pathlib.Path(os.environ['ARCHIVE_PATH'])
manifest = pathlib.Path(os.environ['MANIFEST_PATH'])
payload = {
    'archive': str(archive),
    'archive_sha256': subprocess.check_output(['sha256sum', str(archive)], text=True).split()[0],
    'repo_dir': os.environ['REPO_DIR'],
    'repo_remote': os.environ['REPO_REMOTE'],
    'repo_ref': os.environ['REPO_REF'],
    'resolved_commit': subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip(),
    'extract_root': os.environ['EXTRACT_ROOT'],
    'manifest': str(manifest),
    'manifest_rows': sum(1 for line in manifest.read_text().splitlines() if line.strip()),
}
if os.environ.get('LORA_PATH'):
    payload['lora_path'] = os.environ['LORA_PATH']
    payload['lora_adapter'] = os.environ['LORA_ADAPTER_PATH']
print(json.dumps(payload, indent=2, sort_keys=True))
PY
if [[ "${COLAB_PROVIDER_SETUP_ONLY:-0}" == "1" || "${HUNYUAN3D_SETUP_ONLY:-0}" == "1" || "${TRIPOSR_SETUP_ONLY:-0}" == "1" || "${TRIPOSG_SETUP_ONLY:-0}" == "1" ]]; then
  echo "Provider setup only requested; skipping benchmark stages"
  exit 0
fi
python -u -m backend.benchmark.colab_g4_orchestrator --use-current-repo --run-name g4_stl_first_triposg_prefill_s40_n10 --stage cache --stage eval --stage combine --manifest /content/3dprintpic_colab_inputs/modelnet10_heldout10_stl_first_triposg_prefill/inputs/manifest.jsonl --eval-limit 10 --score-profile stl-quality --cache-download-mode snapshot --cache-max-workers 8 --min-paired-n 10 --max-method-failures 3 --modern-config backend/benchmark/experiment_configs/modelnet10_60_balanced_stl_quality_triposg_prefill_candidates.json --skip-cache --depth-provider depth-anything-v2 --depth-model depth-anything/Depth-Anything-V2-Small-hf --stl-target-dimension 96 --candidate-method triposg_mirror_prefill_repaired_stl_scaled_compact_direct_mesh --current-method mirror --eval-start 0 --allow-missing-split-audit --contact-sheet-methods masked,mirror,biharmonic,source_mesh_oracle,triposg_masked_repaired_stl_scaled_compact_direct_mesh,triposg_mirror_prefill_repaired_stl_scaled_compact_direct_mesh,triposg_biharmonic_prefill_repaired_stl_scaled_compact_direct_mesh --contact-sheet-max-samples 4
) 2>&1 | tee "$RUN_LOG"
run_status="${PIPESTATUS[0]}"
set -e
export RUN_STATUS="$run_status"
python - <<'PY'
from datetime import datetime, timezone
import csv, json, os, pathlib, tarfile

def add_if_exists(tar: tarfile.TarFile, path: pathlib.Path, arcname: str) -> None:
    if path.exists():
        tar.add(path, arcname=arcname)

def read_csv_rows(path: pathlib.Path) -> list[dict]:
    if not path.exists():
        return []
    with path.open(newline='', encoding='utf-8') as csv_file:
        return list(csv.DictReader(csv_file))

def read_json_object(path: pathlib.Path) -> dict:
    if not path.exists():
        return {}
    try:
        return json.loads(path.read_text(encoding='utf-8'))
    except Exception as exc:
        return {'read_error': f'{type(exc).__name__}: {exc}'}

def compact_methods(rows: list[dict]) -> list[dict]:
    keys = [
        'method', 'base_method', 'stl_mode', 'n', 'attempted_n', 'success_rate',
        'error_count', 'logged_failure_count', 'rank_score',
        'mesh_surface_chamfer_l1_median', 'mesh_surface_hausdorff95_median',
        'silhouette_iou_masked_median', 'stl_exists_median', 'stl_is_watertight_median',
        'stl_is_volume_median', 'stl_is_manifold_median', 'stl_positive_volume_median',
        'stl_single_component_median', 'stl_nonmanifold_edge_count_log1p_median',
        'stl_degenerate_face_ratio_median', 'stl_component_excess_log1p_median',
        'stl_bbox_aspect_ratio_median', 'stl_faces_per_bbox_volume_log1p_median',
    ]
    return [{key: row.get(key, '') for key in keys if key in row} for row in rows]

def summarize_benchmark_dir(path: pathlib.Path) -> dict:
    aggregate = path / 'aggregate_summary.csv'
    ranked = path / 'ranked_experiments.csv'
    selection = path / 'selection_decision.json'
    contact_sheet = path / 'artifact_contact_sheet.png'
    aggregate_rows = read_csv_rows(aggregate)
    ranked_rows = read_csv_rows(ranked)
    selection_json = read_json_object(selection)
    digest = {
        'path': str(path),
        'aggregate_summary_exists': aggregate.exists(),
        'ranked_experiments_exists': ranked.exists(),
        'selection_decision_exists': selection.exists(),
        'contact_sheet_exists': contact_sheet.exists(),
        'methods': compact_methods(ranked_rows or aggregate_rows),
    }
    if ranked_rows:
        top = ranked_rows[0]
        digest['top_method'] = top.get('method', '')
        digest['top_rank_score'] = top.get('rank_score', '')
    if selection_json:
        digest['decision'] = selection_json.get('decision', '')
        digest['candidate_method'] = selection_json.get('candidate_method', '')
        digest['failed_checks'] = [check.get('name', '') for check in selection_json.get('failed_checks', [])]
    return digest

output_root = pathlib.Path(os.environ['OUTPUT_ROOT'])
run_log = pathlib.Path(os.environ['RUN_LOG'])
preflight = pathlib.Path(os.environ['PREFLIGHT_PATH'])
summary_path = pathlib.Path(os.environ['RESULTS_SUMMARY'])
archive_path = pathlib.Path(os.environ['RESULTS_ARCHIVE'])
orchestrator_result = output_root / 'orchestrator_result.json'
selection_decisions = sorted(output_root.glob('combined/*/selection_decision.json')) if output_root.exists() else []
eval_summaries = [summarize_benchmark_dir(path) for path in sorted(output_root.glob('experiments/*'))] if output_root.exists() else []
combined_summaries = [summarize_benchmark_dir(path) for path in sorted(output_root.glob('combined/*'))] if output_root.exists() else []
summary = {
    'generated_at': datetime.now(timezone.utc).isoformat(timespec='seconds'),
    'run_name': os.environ['RUN_NAME'],
    'run_status': int(os.environ['RUN_STATUS']),
    'provider_setup_only': os.environ.get('COLAB_PROVIDER_SETUP_ONLY') == '1' or os.environ.get('HUNYUAN3D_SETUP_ONLY') == '1' or os.environ.get('TRIPOSR_SETUP_ONLY') == '1' or os.environ.get('TRIPOSG_SETUP_ONLY') == '1',
    'output_root': str(output_root),
    'output_root_exists': output_root.exists(),
    'run_log': str(run_log),
    'preflight': str(preflight),
    'results_archive': str(archive_path),
    'orchestrator_result': str(orchestrator_result) if orchestrator_result.exists() else '',
    'selection_decisions': [str(path) for path in selection_decisions],
    'eval_summaries': eval_summaries,
    'combined_summaries': combined_summaries,
}
summary_path.write_text(json.dumps(summary, indent=2, sort_keys=True) + '\n', encoding='utf-8')
archive_path.parent.mkdir(parents=True, exist_ok=True)
with tarfile.open(archive_path, 'w:gz') as tar:
    add_if_exists(tar, preflight, 'launch_preflight.json')
    add_if_exists(tar, run_log, 'run_colab_eval.log')
    add_if_exists(tar, summary_path, 'results_summary.json')
    if output_root.exists():
        tar.add(output_root, arcname=f"output/{output_root.name}")
print(json.dumps(summary, indent=2, sort_keys=True))
PY
echo "Results archive: $RESULTS_ARCHIVE"
exit "$run_status"
