#!/usr/bin/env bash
set -euo pipefail

ARCHIVE_PATH="${1:-/content/modelnet10_heldout1_stl_first_triposg_colab_inputs.tar.gz}"
EXTRACT_ROOT="${EXTRACT_ROOT:-/content/3dprintpic_colab_inputs/modelnet10_heldout1_stl_first_triposg}"
REPO_DIR="${REPO_DIR:-/content/3dprintpic}"
REPO_REMOTE="${REPO_REMOTE:-https://github.com/DrStrangel0ve/3dprintpic.git}"
REPO_REF="${REPO_REF:-d6a8e68c54dc93f737273d24bb3cb28855d19073}"

RUN_NAME=g4_stl_first_triposg_s40_n1
RUN_LOG="${RUN_LOG:-/content/3dprintpic_colab_inputs/modelnet10_heldout1_stl_first_triposg/run_colab_eval.log}"
OUTPUT_ROOT="${OUTPUT_ROOT:-$REPO_DIR/backend/output/completion-benchmark/colab_g4/$RUN_NAME}"
RESULTS_SUMMARY="${RESULTS_SUMMARY:-/content/3dprintpic_colab_inputs/modelnet10_heldout1_stl_first_triposg/results_summary.json}"
RESULTS_ARCHIVE="${RESULTS_ARCHIVE:-/content/g4_stl_first_triposg_s40_n1_results.tar.gz}"
MANIFEST_PATH=/content/3dprintpic_colab_inputs/modelnet10_heldout1_stl_first_triposg/inputs/manifest.jsonl
LORA_PATH=''
LORA_ADAPTER_PATH=''
LORA_REPORT_PATH=''
PREFLIGHT_PATH=/content/3dprintpic_colab_inputs/modelnet10_heldout1_stl_first_triposg/launch_preflight.json
export ARCHIVE_PATH EXTRACT_ROOT REPO_DIR REPO_REMOTE REPO_REF RUN_NAME RUN_LOG OUTPUT_ROOT RESULTS_SUMMARY RESULTS_ARCHIVE MANIFEST_PATH LORA_PATH LORA_ADAPTER_PATH LORA_REPORT_PATH PREFLIGHT_PATH
mkdir -p "$EXTRACT_ROOT" "$(dirname "$RUN_LOG")" "$(dirname "$RESULTS_SUMMARY")" "$(dirname "$RESULTS_ARCHIVE")"
set +e
(
set -euo pipefail
export PYTHONUNBUFFERED="${PYTHONUNBUFFERED:-1}"
export PYTORCH_CUDA_ALLOC_CONF="${PYTORCH_CUDA_ALLOC_CONF:-expandable_segments:True}"
export CUDA_MODULE_LOADING="${CUDA_MODULE_LOADING:-LAZY}"
export MALLOC_ARENA_MAX="${MALLOC_ARENA_MAX:-2}"
if [[ -n "${EXPECTED_SHA256:-}" ]]; then
  actual_sha="$(sha256sum "$ARCHIVE_PATH" | awk '{print $1}')"
  if [[ "$actual_sha" != "$EXPECTED_SHA256" ]]; then
    echo "archive sha256 mismatch: expected $EXPECTED_SHA256 got $actual_sha" >&2
    exit 2
  fi
fi
tar -xzf "$ARCHIVE_PATH" -C "$EXTRACT_ROOT"
test -s "$MANIFEST_PATH"
if [[ -n "$LORA_PATH" ]]; then
  test -s "$LORA_ADAPTER_PATH"
  test -s "$LORA_REPORT_PATH"
fi
manifest_rows="$(python - <<'PY'
import os, pathlib
manifest = pathlib.Path(os.environ['MANIFEST_PATH'])
print(sum(1 for line in manifest.read_text().splitlines() if line.strip()))
PY
)"
if [[ "$manifest_rows" -lt 1 ]]; then
  echo "rewritten manifest has no rows" >&2
  exit 2
fi
if [[ ! -d "$REPO_DIR/.git" ]]; then
  rm -rf "$REPO_DIR"
  git clone --filter=blob:none "$REPO_REMOTE" "$REPO_DIR"
fi
cd "$REPO_DIR"
git fetch "$REPO_REMOTE" "$REPO_REF"
git reset --hard FETCH_HEAD
resolved_commit="$(git rev-parse HEAD)"
if [[ "${COLAB_SKIP_BACKEND_INSTALL:-0}" == "1" ]]; then
  echo "Skipping backend pip install because COLAB_SKIP_BACKEND_INSTALL=1"
else
  python -m pip install -U pip
  if [[ -f backend/requirements-cuda.txt ]]; then
    python -m pip install -r backend/requirements-cuda.txt
  else
    python -m pip install -r backend/requirements.txt
  fi
fi
TRIPOSG_DIR="${TRIPOSG_DIR:-/content/TripoSG}"
TRIPOSG_VENV="${TRIPOSG_VENV:-/content/triposg-venv}"
export TRIPOSG_DIR TRIPOSG_VENV
if [[ ! -d "$TRIPOSG_DIR/.git" ]]; then
  rm -rf "$TRIPOSG_DIR"
  git clone --filter=blob:none https://github.com/VAST-AI-Research/TripoSG "$TRIPOSG_DIR"
fi
python -m pip install -q virtualenv
if [[ ! -x "$TRIPOSG_VENV/bin/python" ]]; then
  python -m virtualenv --system-site-packages "$TRIPOSG_VENV"
fi
export PYTHONPATH="$TRIPOSG_DIR:${PYTHONPATH:-}"
if ! "$TRIPOSG_VENV/bin/python" - <<'PY'
import importlib.util
missing = []
for name in ('torch', 'diffusers', 'transformers', 'trimesh', 'triposg.pipelines.pipeline_triposg'):
    try:
        found = importlib.util.find_spec(name) is not None
    except ModuleNotFoundError:
        found = False
    if not found:
        missing.append(name)
if missing:
    print('missing TripoSG Python deps: ' + ', '.join(missing))
    raise SystemExit(1)
PY
then
  "$TRIPOSG_VENV/bin/python" -m pip install -U pip setuptools wheel
  python - <<'PY'
import os
from pathlib import Path
source = Path(os.environ['TRIPOSG_DIR']) / 'requirements.txt'
target = Path('/tmp/triposg_requirements_colab.txt')
skip_prefixes = ('numpy', 'torch', 'torchvision', 'torchaudio')
lines = []
if source.exists():
    for raw in source.read_text().splitlines():
        line = raw.strip()
        if not line or line.startswith('#'):
            continue
        lowered = line.lower()
        if any(lowered == prefix or lowered.startswith(prefix + spec) for prefix in skip_prefixes for spec in ('=', '<', '>', '~', ' ')):
            continue
        lines.append(line)
target.write_text('\n'.join(lines) + ('\n' if lines else ''))
print(target)
PY
  "$TRIPOSG_VENV/bin/python" -m pip install numpy==2.0.2 trimesh==4.12.2 Pillow==10.1.0 huggingface-hub imageio
  if [[ -s /tmp/triposg_requirements_colab.txt ]]; then
    "$TRIPOSG_VENV/bin/python" -m pip install -r /tmp/triposg_requirements_colab.txt
  fi
  "$TRIPOSG_VENV/bin/python" - <<'PY'
import importlib
for name in ('torch', 'diffusers', 'transformers', 'trimesh', 'triposg.pipelines.pipeline_triposg'):
    importlib.import_module(name)
PY
fi
echo "TripoSG setup checkpoint: Python deps importable"
python - <<'PY' > "$PREFLIGHT_PATH"
import json, os, pathlib, subprocess
archive = pathlib.Path(os.environ['ARCHIVE_PATH'])
manifest = pathlib.Path(os.environ['MANIFEST_PATH'])
payload = {
    'archive': str(archive),
    'archive_sha256': subprocess.check_output(['sha256sum', str(archive)], text=True).split()[0],
    'repo_dir': os.environ['REPO_DIR'],
    'repo_remote': os.environ['REPO_REMOTE'],
    'repo_ref': os.environ['REPO_REF'],
    'resolved_commit': subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip(),
    'extract_root': os.environ['EXTRACT_ROOT'],
    'manifest': str(manifest),
    'manifest_rows': sum(1 for line in manifest.read_text().splitlines() if line.strip()),
}
if os.environ.get('LORA_PATH'):
    payload['lora_path'] = os.environ['LORA_PATH']
    payload['lora_adapter'] = os.environ['LORA_ADAPTER_PATH']
print(json.dumps(payload, indent=2, sort_keys=True))
PY
if [[ "${COLAB_PROVIDER_SETUP_ONLY:-0}" == "1" || "${HUNYUAN3D_SETUP_ONLY:-0}" == "1" || "${TRIPOSR_SETUP_ONLY:-0}" == "1" || "${TRIPOSG_SETUP_ONLY:-0}" == "1" ]]; then
  echo "Provider setup only requested; skipping benchmark stages"
  exit 0
fi
python -u -m backend.benchmark.colab_g4_orchestrator --use-current-repo --run-name g4_stl_first_triposg_s40_n1 --stage cache --stage eval --stage combine --manifest /content/3dprintpic_colab_inputs/modelnet10_heldout1_stl_first_triposg/inputs/manifest.jsonl --eval-limit 1 --score-profile stl-quality --cache-download-mode snapshot --cache-max-workers 8 --min-paired-n 1 --max-method-failures 1 --modern-config backend/benchmark/experiment_configs/modelnet10_60_balanced_stl_quality_triposg_direct_mesh_smoke.json --skip-cache --depth-provider depth-anything-v2 --depth-model depth-anything/Depth-Anything-V2-Small-hf --stl-target-dimension 96 --candidate-method triposg_masked_repaired_stl_scaled_compact_direct_mesh --current-method mirror --eval-start 0 --allow-missing-split-audit --contact-sheet-methods masked,mirror,biharmonic,source_mesh_oracle,triposg_masked_repaired_stl_scaled_compact_direct_mesh --contact-sheet-max-samples 1
) 2>&1 | tee "$RUN_LOG"
run_status="${PIPESTATUS[0]}"
set -e
export RUN_STATUS="$run_status"
python - <<'PY'
from datetime import datetime, timezone
import csv, json, os, pathlib, tarfile

def add_if_exists(tar: tarfile.TarFile, path: pathlib.Path, arcname: str) -> None:
    if path.exists():
        tar.add(path, arcname=arcname)

def read_csv_rows(path: pathlib.Path) -> list[dict]:
    if not path.exists():
        return []
    with path.open(newline='', encoding='utf-8') as csv_file:
        return list(csv.DictReader(csv_file))

def read_json_object(path: pathlib.Path) -> dict:
    if not path.exists():
        return {}
    try:
        return json.loads(path.read_text(encoding='utf-8'))
    except Exception as exc:
        return {'read_error': f'{type(exc).__name__}: {exc}'}

def compact_methods(rows: list[dict]) -> list[dict]:
    keys = [
        'method', 'base_method', 'stl_mode', 'n', 'attempted_n', 'success_rate',
        'error_count', 'logged_failure_count', 'rank_score',
        'mesh_surface_chamfer_l1_median', 'mesh_surface_hausdorff95_median',
        'silhouette_iou_masked_median', 'stl_exists_median', 'stl_is_watertight_median',
        'stl_is_volume_median', 'stl_is_manifold_median', 'stl_positive_volume_median',
        'stl_single_component_median', 'stl_nonmanifold_edge_count_log1p_median',
        'stl_degenerate_face_ratio_median', 'stl_component_excess_log1p_median',
        'stl_bbox_aspect_ratio_median', 'stl_faces_per_bbox_volume_log1p_median',
    ]
    return [{key: row.get(key, '') for key in keys if key in row} for row in rows]

def summarize_benchmark_dir(path: pathlib.Path) -> dict:
    aggregate = path / 'aggregate_summary.csv'
    ranked = path / 'ranked_experiments.csv'
    selection = path / 'selection_decision.json'
    contact_sheet = path / 'artifact_contact_sheet.png'
    aggregate_rows = read_csv_rows(aggregate)
    ranked_rows = read_csv_rows(ranked)
    selection_json = read_json_object(selection)
    digest = {
        'path': str(path),
        'aggregate_summary_exists': aggregate.exists(),
        'ranked_experiments_exists': ranked.exists(),
        'selection_decision_exists': selection.exists(),
        'contact_sheet_exists': contact_sheet.exists(),
        'methods': compact_methods(ranked_rows or aggregate_rows),
    }
    if ranked_rows:
        top = ranked_rows[0]
        digest['top_method'] = top.get('method', '')
        digest['top_rank_score'] = top.get('rank_score', '')
    if selection_json:
        digest['decision'] = selection_json.get('decision', '')
        digest['candidate_method'] = selection_json.get('candidate_method', '')
        digest['failed_checks'] = [check.get('name', '') for check in selection_json.get('failed_checks', [])]
    return digest

output_root = pathlib.Path(os.environ['OUTPUT_ROOT'])
run_log = pathlib.Path(os.environ['RUN_LOG'])
preflight = pathlib.Path(os.environ['PREFLIGHT_PATH'])
summary_path = pathlib.Path(os.environ['RESULTS_SUMMARY'])
archive_path = pathlib.Path(os.environ['RESULTS_ARCHIVE'])
orchestrator_result = output_root / 'orchestrator_result.json'
selection_decisions = sorted(output_root.glob('combined/*/selection_decision.json')) if output_root.exists() else []
eval_summaries = [summarize_benchmark_dir(path) for path in sorted(output_root.glob('experiments/*'))] if output_root.exists() else []
combined_summaries = [summarize_benchmark_dir(path) for path in sorted(output_root.glob('combined/*'))] if output_root.exists() else []
summary = {
    'generated_at': datetime.now(timezone.utc).isoformat(timespec='seconds'),
    'run_name': os.environ['RUN_NAME'],
    'run_status': int(os.environ['RUN_STATUS']),
    'provider_setup_only': os.environ.get('COLAB_PROVIDER_SETUP_ONLY') == '1' or os.environ.get('HUNYUAN3D_SETUP_ONLY') == '1' or os.environ.get('TRIPOSR_SETUP_ONLY') == '1' or os.environ.get('TRIPOSG_SETUP_ONLY') == '1',
    'output_root': str(output_root),
    'output_root_exists': output_root.exists(),
    'run_log': str(run_log),
    'preflight': str(preflight),
    'results_archive': str(archive_path),
    'orchestrator_result': str(orchestrator_result) if orchestrator_result.exists() else '',
    'selection_decisions': [str(path) for path in selection_decisions],
    'eval_summaries': eval_summaries,
    'combined_summaries': combined_summaries,
}
summary_path.write_text(json.dumps(summary, indent=2, sort_keys=True) + '\n', encoding='utf-8')
archive_path.parent.mkdir(parents=True, exist_ok=True)
with tarfile.open(archive_path, 'w:gz') as tar:
    add_if_exists(tar, preflight, 'launch_preflight.json')
    add_if_exists(tar, run_log, 'run_colab_eval.log')
    add_if_exists(tar, summary_path, 'results_summary.json')
    if output_root.exists():
        tar.add(output_root, arcname=f"output/{output_root.name}")
print(json.dumps(summary, indent=2, sort_keys=True))
PY
echo "Results archive: $RESULTS_ARCHIVE"
exit "$run_status"
