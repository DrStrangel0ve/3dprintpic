#!/usr/bin/env bash
set -euo pipefail

ARCHIVE_PATH="${1:-/content/g4_stl_first_trellis2_component_close_s40_n5_commit206142f.tar.gz}"
EXTRACT_ROOT="${EXTRACT_ROOT:-/content/3dprintpic_colab_inputs}"
REPO_DIR="${REPO_DIR:-/content/3dprintpic}"
REPO_REMOTE="${REPO_REMOTE:-https://github.com/DrStrangel0ve/3dprintpic.git}"
REPO_REF="${REPO_REF:-206142fc36fecdbbfa21b9b15ea03f8f2d55379a}"

RUN_NAME=g4_stl_first_trellis2_component_close_s40_n5
RUN_LOG="${RUN_LOG:-/content/3dprintpic_colab_inputs/run_colab_eval.log}"
OUTPUT_ROOT="${OUTPUT_ROOT:-$REPO_DIR/backend/output/completion-benchmark/colab_g4/$RUN_NAME}"
RESULTS_SUMMARY="${RESULTS_SUMMARY:-/content/3dprintpic_colab_inputs/results_summary.json}"
RESULTS_ARCHIVE="${RESULTS_ARCHIVE:-/content/g4_stl_first_trellis2_component_close_s40_n5_results.tar.gz}"
RESULTS_COMPACT_ARCHIVE="${RESULTS_COMPACT_ARCHIVE:-/content/g4_stl_first_trellis2_component_close_s40_n5_results_compact.tar.gz}"
STL_INGEST_DIR="${STL_INGEST_DIR:-/content/g4_stl_first_trellis2_component_close_s40_n5_stl_first_ingest}"
STL_INGEST_JSON="${STL_INGEST_JSON:-/content/g4_stl_first_trellis2_component_close_s40_n5_stl_first_ingest/stl_first_ingest_report.json}"
STL_INGEST_MD="${STL_INGEST_MD:-/content/g4_stl_first_trellis2_component_close_s40_n5_stl_first_ingest/stl_first_ingest_report.md}"
MANIFEST_PATH=/content/3dprintpic_colab_inputs/inputs/manifest.jsonl
LORA_PATH=''
LORA_ADAPTER_PATH=''
LORA_REPORT_PATH=''
GPU_PREFLIGHT_PATH=/content/3dprintpic_colab_inputs/gpu_preflight.json
PREFLIGHT_PATH=/content/3dprintpic_colab_inputs/launch_preflight.json
TRELLIS2_PREFLIGHT_PATH=/content/3dprintpic_colab_inputs/trellis2_provider_preflight.json
HUNYUAN3D_2MV_PREFLIGHT_PATH=/content/3dprintpic_colab_inputs/hunyuan3d_2mv_provider_preflight.json
COLAB_REQUIRE_GPU_NAME_REGEX="${COLAB_REQUIRE_GPU_NAME_REGEX:-}"
if [[ -z "$COLAB_REQUIRE_GPU_NAME_REGEX" ]]; then
  COLAB_REQUIRE_GPU_NAME_REGEX='RTX PRO 6000|Blackwell|G4'
fi
COLAB_MIN_GPU_MEMORY_GB="${COLAB_MIN_GPU_MEMORY_GB:-}"
if [[ -z "$COLAB_MIN_GPU_MEMORY_GB" ]]; then
  COLAB_MIN_GPU_MEMORY_GB=90.0
fi
export ARCHIVE_PATH EXTRACT_ROOT REPO_DIR REPO_REMOTE REPO_REF RUN_NAME RUN_LOG OUTPUT_ROOT RESULTS_SUMMARY RESULTS_ARCHIVE RESULTS_COMPACT_ARCHIVE STL_INGEST_DIR STL_INGEST_JSON STL_INGEST_MD MANIFEST_PATH LORA_PATH LORA_ADAPTER_PATH LORA_REPORT_PATH GPU_PREFLIGHT_PATH PREFLIGHT_PATH TRELLIS2_PREFLIGHT_PATH HUNYUAN3D_2MV_PREFLIGHT_PATH COLAB_REQUIRE_GPU_NAME_REGEX COLAB_MIN_GPU_MEMORY_GB
mkdir -p "$EXTRACT_ROOT" "$(dirname "$RUN_LOG")" "$(dirname "$RESULTS_SUMMARY")" "$(dirname "$RESULTS_ARCHIVE")" "$(dirname "$RESULTS_COMPACT_ARCHIVE")" "$STL_INGEST_DIR"
set +e
(
set -euo pipefail
export PYTHONUNBUFFERED="${PYTHONUNBUFFERED:-1}"
export PYTORCH_CUDA_ALLOC_CONF="${PYTORCH_CUDA_ALLOC_CONF:-expandable_segments:True}"
export CUDA_MODULE_LOADING="${CUDA_MODULE_LOADING:-LAZY}"
export MALLOC_ARENA_MAX="${MALLOC_ARENA_MAX:-2}"
python - <<'PY' | tee "$GPU_PREFLIGHT_PATH"
import json, os, re, shutil, subprocess

required_name = os.environ.get('COLAB_REQUIRE_GPU_NAME_REGEX', '').strip()
min_memory_raw = os.environ.get('COLAB_MIN_GPU_MEMORY_GB', '').strip()
min_memory_gb = None
errors = []
if min_memory_raw:
    try:
        min_memory_gb = float(min_memory_raw)
    except ValueError:
        errors.append(f'invalid COLAB_MIN_GPU_MEMORY_GB={min_memory_raw!r}')
    else:
        if min_memory_gb < 0:
            errors.append(f'COLAB_MIN_GPU_MEMORY_GB must be non-negative, got {min_memory_gb}')

query_error = ''
gpus = []
if shutil.which('nvidia-smi'):
    try:
        output = subprocess.check_output(
            [
                'nvidia-smi',
                '--query-gpu=name,memory.total',
                '--format=csv,noheader,nounits',
            ],
            text=True,
            stderr=subprocess.STDOUT,
        )
    except subprocess.CalledProcessError as exc:
        query_error = exc.output.strip() or f'nvidia-smi exited with {exc.returncode}'
    else:
        for line in output.splitlines():
            line = line.strip()
            if not line:
                continue
            name, _, memory_text = line.partition(',')
            name = name.strip()
            memory_text = memory_text.strip()
            memory_mib = None
            if memory_text:
                try:
                    memory_mib = float(memory_text)
                except ValueError:
                    pass
            gpu = {'index': len(gpus), 'name': name, 'memory_total_mib': memory_mib}
            if memory_mib is not None:
                gpu['memory_total_gb'] = memory_mib / 1024.0
            gpus.append(gpu)
else:
    query_error = 'nvidia-smi not found'

eligible = list(gpus)
if required_name:
    try:
        pattern = re.compile(required_name, re.IGNORECASE)
    except re.error as exc:
        errors.append(f'invalid COLAB_REQUIRE_GPU_NAME_REGEX={required_name!r}: {exc}')
        eligible = []
    else:
        eligible = [gpu for gpu in eligible if pattern.search(gpu.get('name') or '')]
if min_memory_gb is not None:
    eligible = [gpu for gpu in eligible if (gpu.get('memory_total_gb') or 0.0) >= min_memory_gb]

guard_requested = bool(required_name or min_memory_raw)
if guard_requested:
    if query_error:
        errors.append(query_error)
    elif not gpus:
        errors.append('no NVIDIA GPUs reported by nvidia-smi')
    elif not eligible:
        seen = ', '.join(
            f"{gpu.get('name') or 'unknown'} ({gpu.get('memory_total_gb', 0.0):.1f} GB)"
            for gpu in gpus
        )
        errors.append(
            'no GPU satisfied COLAB_REQUIRE_GPU_NAME_REGEX='
            f'{required_name!r} and COLAB_MIN_GPU_MEMORY_GB={min_memory_raw!r}; saw {seen}'
        )

payload = {
    'ok': not errors,
    'guard_requested': guard_requested,
    'requirements': {
        'name_regex': required_name,
        'min_memory_gb': min_memory_gb,
    },
    'cuda_visible_devices': os.environ.get('CUDA_VISIBLE_DEVICES', ''),
    'nvidia_smi_available': bool(shutil.which('nvidia-smi')),
    'nvidia_smi_error': query_error,
    'gpus': gpus,
    'eligible_gpus': eligible,
    'errors': errors,
}
print(json.dumps(payload, indent=2, sort_keys=True))
if errors:
    raise SystemExit('Colab GPU preflight failed: ' + '; '.join(errors))
PY
if [[ -n "${EXPECTED_SHA256:-}" ]]; then
  actual_sha="$(sha256sum "$ARCHIVE_PATH" | awk '{print $1}')"
  if [[ "$actual_sha" != "$EXPECTED_SHA256" ]]; then
    echo "archive sha256 mismatch: expected $EXPECTED_SHA256 got $actual_sha" >&2
    exit 2
  fi
fi
tar -xzf "$ARCHIVE_PATH" -C "$EXTRACT_ROOT"
test -s "$MANIFEST_PATH"
if [[ -n "$LORA_PATH" ]]; then
  test -s "$LORA_ADAPTER_PATH"
  test -s "$LORA_REPORT_PATH"
fi
manifest_rows="$(python - <<'PY'
import os, pathlib
manifest = pathlib.Path(os.environ['MANIFEST_PATH'])
print(sum(1 for line in manifest.read_text().splitlines() if line.strip()))
PY
)"
if [[ "$manifest_rows" -lt 1 ]]; then
  echo "rewritten manifest has no rows" >&2
  exit 2
fi
if [[ ! -d "$REPO_DIR/.git" ]]; then
  rm -rf "$REPO_DIR"
  git clone --filter=blob:none "$REPO_REMOTE" "$REPO_DIR"
fi
cd "$REPO_DIR"
git fetch "$REPO_REMOTE" "$REPO_REF"
git reset --hard FETCH_HEAD
resolved_commit="$(git rev-parse HEAD)"
if [[ "${COLAB_SKIP_BACKEND_INSTALL:-0}" == "1" ]]; then
  echo "Skipping backend pip install because COLAB_SKIP_BACKEND_INSTALL=1"
else
  python -m pip install -U pip
  if [[ -f backend/requirements-cuda.txt ]]; then
    python -m pip install -r backend/requirements-cuda.txt
  else
    python -m pip install -r backend/requirements.txt
  fi
fi
TRIPOSG_DIR="${TRIPOSG_DIR:-/content/TripoSG}"
TRIPOSG_VENV="${TRIPOSG_VENV:-/content/triposg-venv}"
TRIPOSG_REF="${TRIPOSG_REF:-fc5c40990181e2a756c4e0b1c2f4d6b5202faf8c}"
TRIPOSG_MODEL_REVISION="${TRIPOSG_MODEL_REVISION:-2c1c516d22d58db486a058d98d31bb6177344e06}"
TRIPOSG_REMBG_REVISION="${TRIPOSG_REMBG_REVISION:-2ceba5a5efaec153162aedea169f76caf9b46cf8}"
export TRIPOSG_DIR TRIPOSG_VENV TRIPOSG_REF TRIPOSG_MODEL_REVISION TRIPOSG_REMBG_REVISION
if [[ ! -d "$TRIPOSG_DIR/.git" ]]; then
  rm -rf "$TRIPOSG_DIR"
  git clone --filter=blob:none https://github.com/VAST-AI-Research/TripoSG "$TRIPOSG_DIR"
  git -C "$TRIPOSG_DIR" checkout "$TRIPOSG_REF"
else
  git -C "$TRIPOSG_DIR" fetch --filter=blob:none origin "$TRIPOSG_REF" || git -C "$TRIPOSG_DIR" fetch --filter=blob:none origin main
  git -C "$TRIPOSG_DIR" checkout "$TRIPOSG_REF"
fi
git -C "$TRIPOSG_DIR" reset --hard "$TRIPOSG_REF"
python - <<'PY'
import os
from pathlib import Path
root = Path(os.environ['TRIPOSG_DIR'])
inference_utils = root / 'triposg' / 'inference_utils.py'
text = inference_utils.read_text()
text = text.replace('from diso import DiffDMC\n', '')
needle = '        dmc = DiffDMC(dtype=torch.float32).to(grid_logits.device)\n'
replacement = '        from diso import DiffDMC\n        dmc = DiffDMC(dtype=torch.float32).to(grid_logits.device)\n'
if replacement not in text:
    text = text.replace(needle, replacement)
inference_utils.write_text(text)
script = root / 'scripts' / 'inference_triposg.py'
text = script.read_text()
needle = '        guidance_scale=guidance_scale,\n    ).samples[0]'
replacement = '        guidance_scale=guidance_scale,\n        use_flash_decoder=os.environ.get("TRIPOSG_USE_FLASH_DECODER", "0") == "1",\n    ).samples[0]'
if 'TRIPOSG_USE_FLASH_DECODER' not in text:
    text = text.replace(needle, replacement)
script.write_text(text)
print('TripoSG setup checkpoint: non-flash decoder patch applied')
PY
python -m backend.benchmark.patch_triposg_sources --triposg-dir "$TRIPOSG_DIR"
python -m pip install -q virtualenv
if [[ ! -x "$TRIPOSG_VENV/bin/python" ]]; then
  python -m virtualenv --system-site-packages "$TRIPOSG_VENV"
fi
export PYTHONPATH="$TRIPOSG_DIR:${PYTHONPATH:-}"
if ! "$TRIPOSG_VENV/bin/python" - <<'PY'
import os
import importlib
missing = []
required = ['torch', 'diffusers', 'transformers', 'trimesh', 'fast_simplification', 'triposg.pipelines.pipeline_triposg']
if os.environ.get('TRIPOSG_INSTALL_DISO') == '1' or os.environ.get('TRIPOSG_USE_FLASH_DECODER') == '1':
    required.append('diso')
for name in required:
    try:
        importlib.import_module(name)
    except Exception as exc:
        missing.append(f'{name} ({type(exc).__name__}: {exc})')
if missing:
    print('missing TripoSG Python deps: ' + ', '.join(missing))
    raise SystemExit(1)
PY
then
  "$TRIPOSG_VENV/bin/python" -m pip install -U pip setuptools wheel
  python - <<'PY'
import os
from pathlib import Path
source = Path(os.environ['TRIPOSG_DIR']) / 'requirements.txt'
target = Path('/tmp/triposg_requirements_colab.txt')
skip_prefixes = ('numpy', 'torch', 'torchvision', 'torchaudio')
lines = []
if source.exists():
    for raw in source.read_text().splitlines():
        line = raw.strip()
        if not line or line.startswith('#'):
            continue
        lowered = line.lower()
        if os.environ.get('TRIPOSG_INSTALL_DISO') != '1' and (lowered == 'diso' or lowered.startswith('diso' + ' ')):
            continue
        if any(lowered == prefix or lowered.startswith(prefix + spec) for prefix in skip_prefixes for spec in ('=', '<', '>', '~', ' ')):
            continue
        lines.append(line)
target.write_text('\n'.join(lines) + ('\n' if lines else ''))
print(target)
PY
  "$TRIPOSG_VENV/bin/python" -m pip install numpy==2.0.2 trimesh==4.12.2 fast-simplification Pillow==10.1.0 huggingface-hub imageio packaging ninja
  if [[ "${TRIPOSG_INSTALL_DISO:-0}" == "1" || "${TRIPOSG_USE_FLASH_DECODER:-0}" == "1" ]]; then
    export CUDA_HOME="${CUDA_HOME:-/usr/local/cuda}"
    export PATH="$CUDA_HOME/bin:$PATH"
    export LD_LIBRARY_PATH="$CUDA_HOME/lib64:${LD_LIBRARY_PATH:-}"
    export FORCE_CUDA="${FORCE_CUDA:-1}"
    export TORCH_CUDA_ARCH_LIST="${TORCH_CUDA_ARCH_LIST:-12.0}"
    export MAX_JOBS="${MAX_JOBS:-1}"
    export NVCC_FLAGS="${NVCC_FLAGS:--O3 --threads 1}"
    "$TRIPOSG_VENV/bin/python" -m pip install -v --no-cache-dir --no-build-isolation --no-binary=:all: diso==0.1.4
  fi
  if [[ -s /tmp/triposg_requirements_colab.txt ]]; then
    "$TRIPOSG_VENV/bin/python" -m pip install -r /tmp/triposg_requirements_colab.txt
  fi
  "$TRIPOSG_VENV/bin/python" - <<'PY'
import os
import importlib
required = ['torch', 'diffusers', 'transformers', 'trimesh', 'fast_simplification', 'triposg.pipelines.pipeline_triposg']
if os.environ.get('TRIPOSG_INSTALL_DISO') == '1' or os.environ.get('TRIPOSG_USE_FLASH_DECODER') == '1':
    required.append('diso')
for name in required:
    importlib.import_module(name)
PY
fi
echo "TripoSG setup checkpoint: Python deps importable"
(cd "$TRIPOSG_DIR" && "$TRIPOSG_VENV/bin/python" -m scripts.inference_triposg --help >/tmp/triposg_inference_help.txt)
echo "TripoSG setup checkpoint: CLI imports ok"
if [[ "${TRIPOSG_PREFETCH:-0}" == "1" ]]; then
  "$TRIPOSG_VENV/bin/python" - <<'PY'
import os
from pathlib import Path
import torch
from huggingface_hub import snapshot_download
if not torch.cuda.is_available():
    raise SystemExit('TripoSG prefetch requires CUDA, but torch.cuda.is_available() is false')
props = torch.cuda.get_device_properties(0)
total_gb = props.total_memory / (1024 ** 3)
print(f'TripoSG CUDA device: {props.name}, VRAM={total_gb:.1f} GB')
if total_gb < 8:
    raise SystemExit(f'TripoSG needs at least about 8 GB VRAM, got {total_gb:.1f} GB')
root = Path(os.environ['TRIPOSG_DIR'])
specs = (
    ('VAST-AI/TripoSG', os.environ['TRIPOSG_MODEL_REVISION'], root / 'pretrained_weights' / 'TripoSG'),
    ('briaai/RMBG-1.4', os.environ['TRIPOSG_REMBG_REVISION'], root / 'pretrained_weights' / 'RMBG-1.4'),
)
for repo_id, revision, local_dir in specs:
    path = snapshot_download(repo_id=repo_id, revision=revision, local_dir=local_dir)
    print(f'TripoSG prefetched {repo_id}@{revision}: {path}')
PY
  export TRIPOSG_HF_LOCAL_ONLY=1
  echo "TripoSG setup checkpoint: weights prefetched"
fi
TRELLIS2_DIR="${TRELLIS2_DIR:-/content/TRELLIS.2}"
TRELLIS2_VENV="${TRELLIS2_VENV:-/content/trellis2-venv}"
TRELLIS2_DEPS_SRC="${TRELLIS2_DEPS_SRC:-/content/trellis2-deps-src}"
TRELLIS2_REF="${TRELLIS2_REF:-75fbf0183001ed9876c8dbb35de6b68552ee08bd}"
TRELLIS2_MODEL_ID="${TRELLIS2_MODEL_ID:-microsoft/TRELLIS.2-4B}"
TRELLIS2_MODEL_REVISION="${TRELLIS2_MODEL_REVISION:-af44b45f2e35a493886929c6d786e563ec68364d}"
TRELLIS2_RESOLUTION="${TRELLIS2_RESOLUTION:-512}"
TRELLIS2_ATTN_BACKEND="${TRELLIS2_ATTN_BACKEND:-xformers}"
TRELLIS2_XFORMERS_VERSION="${TRELLIS2_XFORMERS_VERSION:-0.0.35}"
TRELLIS2_CUMESH_DIR="${TRELLIS2_CUMESH_DIR:-$TRELLIS2_DEPS_SRC/CuMesh}"
TRELLIS2_CUMESH_REF="${TRELLIS2_CUMESH_REF:-12289e1062f0603f2f0d0771b02e1395d247f26f}"
TRELLIS2_FLEXGEMM_DIR="${TRELLIS2_FLEXGEMM_DIR:-$TRELLIS2_DEPS_SRC/FlexGEMM}"
TRELLIS2_FLEXGEMM_REF="${TRELLIS2_FLEXGEMM_REF:-6dd94a859c26ee8246888502eada3dd8ad85532e}"
TRELLIS2_NVDIFFRAST_DIR="${TRELLIS2_NVDIFFRAST_DIR:-$TRELLIS2_DEPS_SRC/nvdiffrast}"
TRELLIS2_NVDIFFRAST_REF="${TRELLIS2_NVDIFFRAST_REF:-253ac4fcea7de5f396371124af597e6cc957bfae}"
if [[ "$TRELLIS2_ATTN_BACKEND" != "xformers" ]]; then
  echo "The reproducible TRELLIS.2 Colab setup installs xformers; got TRELLIS2_ATTN_BACKEND=$TRELLIS2_ATTN_BACKEND" >&2
  exit 2
fi
TRELLIS2_HAD_ATTN_BACKEND="${ATTN_BACKEND+x}"
TRELLIS2_PREVIOUS_ATTN_BACKEND="${ATTN_BACKEND-}"
TRELLIS2_HAD_SPARSE_ATTN_BACKEND="${SPARSE_ATTN_BACKEND+x}"
TRELLIS2_PREVIOUS_SPARSE_ATTN_BACKEND="${SPARSE_ATTN_BACKEND-}"
export TRELLIS2_DIR TRELLIS2_VENV TRELLIS2_DEPS_SRC TRELLIS2_REF TRELLIS2_MODEL_ID TRELLIS2_MODEL_REVISION TRELLIS2_RESOLUTION TRELLIS2_ATTN_BACKEND TRELLIS2_XFORMERS_VERSION
export TRELLIS2_CUMESH_DIR TRELLIS2_CUMESH_REF TRELLIS2_FLEXGEMM_DIR TRELLIS2_FLEXGEMM_REF TRELLIS2_NVDIFFRAST_DIR TRELLIS2_NVDIFFRAST_REF
export ATTN_BACKEND="$TRELLIS2_ATTN_BACKEND"
export SPARSE_ATTN_BACKEND="$TRELLIS2_ATTN_BACKEND"
export CUDA_HOME="${CUDA_HOME:-/usr/local/cuda}"
export PATH="$CUDA_HOME/bin:$PATH"
export LD_LIBRARY_PATH="$CUDA_HOME/lib64:${LD_LIBRARY_PATH:-}"
export MAX_JOBS="${MAX_JOBS:-4}"
mkdir -p "$TRELLIS2_DEPS_SRC"
if [[ ! -d "$TRELLIS2_DIR/.git" ]]; then
  rm -rf "$TRELLIS2_DIR"
  git clone --filter=blob:none --recurse-submodules https://github.com/microsoft/TRELLIS.2 "$TRELLIS2_DIR"
fi
git -C "$TRELLIS2_DIR" fetch --filter=blob:none origin "$TRELLIS2_REF" || git -C "$TRELLIS2_DIR" fetch --filter=blob:none origin main
git -C "$TRELLIS2_DIR" checkout --detach "$TRELLIS2_REF"
git -C "$TRELLIS2_DIR" reset --hard "$TRELLIS2_REF"
git -C "$TRELLIS2_DIR" submodule update --init --recursive
test "$(git -C "$TRELLIS2_DIR" rev-parse HEAD)" = "$TRELLIS2_REF"
if [[ ! -d "$TRELLIS2_CUMESH_DIR/.git" ]]; then
  rm -rf "$TRELLIS2_CUMESH_DIR"
  git clone --filter=blob:none --recurse-submodules https://github.com/JeffreyXiang/CuMesh.git "$TRELLIS2_CUMESH_DIR"
fi
git -C "$TRELLIS2_CUMESH_DIR" fetch --filter=blob:none origin "$TRELLIS2_CUMESH_REF" || git -C "$TRELLIS2_CUMESH_DIR" fetch --filter=blob:none origin main
git -C "$TRELLIS2_CUMESH_DIR" checkout --detach "$TRELLIS2_CUMESH_REF"
git -C "$TRELLIS2_CUMESH_DIR" reset --hard "$TRELLIS2_CUMESH_REF"
git -C "$TRELLIS2_CUMESH_DIR" submodule update --init --recursive
test "$(git -C "$TRELLIS2_CUMESH_DIR" rev-parse HEAD)" = "$TRELLIS2_CUMESH_REF"
if [[ ! -d "$TRELLIS2_FLEXGEMM_DIR/.git" ]]; then
  rm -rf "$TRELLIS2_FLEXGEMM_DIR"
  git clone --filter=blob:none --recurse-submodules https://github.com/JeffreyXiang/FlexGEMM.git "$TRELLIS2_FLEXGEMM_DIR"
fi
git -C "$TRELLIS2_FLEXGEMM_DIR" fetch --filter=blob:none origin "$TRELLIS2_FLEXGEMM_REF" || git -C "$TRELLIS2_FLEXGEMM_DIR" fetch --filter=blob:none origin main
git -C "$TRELLIS2_FLEXGEMM_DIR" checkout --detach "$TRELLIS2_FLEXGEMM_REF"
git -C "$TRELLIS2_FLEXGEMM_DIR" reset --hard "$TRELLIS2_FLEXGEMM_REF"
git -C "$TRELLIS2_FLEXGEMM_DIR" submodule update --init --recursive
test "$(git -C "$TRELLIS2_FLEXGEMM_DIR" rev-parse HEAD)" = "$TRELLIS2_FLEXGEMM_REF"
if [[ ! -d "$TRELLIS2_NVDIFFRAST_DIR/.git" ]]; then
  rm -rf "$TRELLIS2_NVDIFFRAST_DIR"
  git clone --filter=blob:none --branch v0.4.0 https://github.com/NVlabs/nvdiffrast.git "$TRELLIS2_NVDIFFRAST_DIR"
fi
git -C "$TRELLIS2_NVDIFFRAST_DIR" fetch --filter=blob:none origin "$TRELLIS2_NVDIFFRAST_REF" || git -C "$TRELLIS2_NVDIFFRAST_DIR" fetch --filter=blob:none origin v0.4.0
git -C "$TRELLIS2_NVDIFFRAST_DIR" checkout --detach "$TRELLIS2_NVDIFFRAST_REF"
git -C "$TRELLIS2_NVDIFFRAST_DIR" reset --hard "$TRELLIS2_NVDIFFRAST_REF"
test "$(git -C "$TRELLIS2_NVDIFFRAST_DIR" rev-parse HEAD)" = "$TRELLIS2_NVDIFFRAST_REF"
python -m pip install -q virtualenv
if [[ ! -x "$TRELLIS2_VENV/bin/python" ]]; then
  python -m virtualenv --system-site-packages "$TRELLIS2_VENV"
fi
TRELLIS2_PYTHON="$TRELLIS2_VENV/bin/python"
export TRELLIS2_PYTHON
export PYTHONPATH="$TRELLIS2_DIR:${PYTHONPATH:-}"
if ! command -v nvcc >/dev/null 2>&1; then
  echo "TRELLIS.2 CUDA extension build requires nvcc" >&2
  exit 2
fi
if ! nvcc --version | grep -Eq 'release 12\.8([, ]|$)'; then
  echo "TRELLIS.2 G4 setup requires a CUDA 12.8 toolkit to match Torch cu128" >&2
  exit 2
fi
TRELLIS2_TORCH_CUDA_ARCH="$("$TRELLIS2_PYTHON" - <<'PY'
import torch
if torch.__version__.split('+', 1)[0] != '2.11.0':
    raise SystemExit(f'TRELLIS.2 G4 setup requires Torch 2.11.0, got {torch.__version__}')
if torch.version.cuda != '12.8':
    raise SystemExit(f'TRELLIS.2 G4 setup requires Torch cu128, got CUDA {torch.version.cuda}')
if not torch.cuda.is_available():
    raise SystemExit('TRELLIS.2 setup requires CUDA')
major, minor = torch.cuda.get_device_capability(0)
print(f'{major}.{minor}')
PY
)"
export TORCH_CUDA_ARCH_LIST="${TORCH_CUDA_ARCH_LIST:-$TRELLIS2_TORCH_CUDA_ARCH}"
export CMAKE_CUDA_ARCHITECTURES="${CMAKE_CUDA_ARCHITECTURES:-${TRELLIS2_TORCH_CUDA_ARCH/./}}"
if ! "$TRELLIS2_PYTHON" - <<'PY'
import importlib
from importlib.metadata import version
for name in ('xformers.ops', 'o_voxel', 'cumesh', 'flex_gemm', 'nvdiffrast.torch'):
    importlib.import_module(name)
if version('xformers') != __import__('os').environ['TRELLIS2_XFORMERS_VERSION']:
    raise SystemExit(1)
from trellis2.pipelines import Trellis2ImageTo3DPipeline
PY
then
  "$TRELLIS2_PYTHON" -m pip install -U pip setuptools wheel ninja cmake packaging
  "$TRELLIS2_PYTHON" -m pip install --no-deps "xformers==$TRELLIS2_XFORMERS_VERSION" --index-url https://download.pytorch.org/whl/cu128
  "$TRELLIS2_PYTHON" -m pip install imageio==2.37.0 imageio-ffmpeg==0.6.0 tqdm==4.67.1 easydict==1.13 ninja==1.11.1.3 trimesh==4.12.2 lpips==0.1.4 zstandard==0.23.0 kornia==0.8.1 timm==1.0.22
  "$TRELLIS2_PYTHON" -m pip install --no-deps "git+https://github.com/EasternJournalist/utils3d.git@9a4eb15e4021b67b12c460c7057d642626897ec8"
  "$TRELLIS2_PYTHON" -m pip install -v --no-deps --no-build-isolation "$TRELLIS2_NVDIFFRAST_DIR"
  "$TRELLIS2_PYTHON" -m pip install -v --no-deps --no-build-isolation "$TRELLIS2_CUMESH_DIR"
  "$TRELLIS2_PYTHON" -m pip install -v --no-deps --no-build-isolation "$TRELLIS2_FLEXGEMM_DIR"
  "$TRELLIS2_PYTHON" -m pip install -v --no-deps --no-build-isolation "$TRELLIS2_DIR/o-voxel"
fi
"$TRELLIS2_PYTHON" - <<'PY'
import json
import os
from importlib.metadata import version
import torch
import xformers.ops as xops
import trellis2.pipelines
from trellis2.modules.sparse import config as sparse_config
from trellis2.pipelines import Trellis2ImageTo3DPipeline
accepted = ('xformers', 'flash_attn', 'flash_attn_3')
requested = os.environ.get('SPARSE_ATTN_BACKEND') or os.environ.get('ATTN_BACKEND') or ''
if requested not in accepted or sparse_config.ATTN != requested:
    raise SystemExit(f'Invalid TRELLIS.2 sparse attention backend: requested={requested!r}, active={sparse_config.ATTN!r}')
if version('xformers') != os.environ['TRELLIS2_XFORMERS_VERSION']:
    raise SystemExit(f'Unexpected xformers version: {version("xformers")}')
query = torch.randn((1, 32, 1, 64), device='cuda', dtype=torch.float16)
mask = xops.fmha.BlockDiagonalMask.from_seqlens([32])
output = xops.memory_efficient_attention(query, query, query, mask)
torch.cuda.synchronize()
props = torch.cuda.get_device_properties(0)
print(json.dumps({
    'event': 'trellis2_backend_ready',
    'python': __import__('sys').executable,
    'pipelines_importable': True,
    'pipeline_class': Trellis2ImageTo3DPipeline.__name__,
    'attention_backend': sparse_config.ATTN,
    'attention_smoke_shape': list(output.shape),
    'xformers_version': version('xformers'),
    'torch_version': torch.__version__,
    'gpu': props.name,
}, sort_keys=True))
PY
echo "TRELLIS.2 setup checkpoint: provider imports and xformers CUDA attention ready"
TRELLIS2_PREFLIGHT_COMMAND="$TRELLIS2_PYTHON -m backend.benchmark.run_image_to_mesh_provider --provider trellis2 --provider-dir $TRELLIS2_DIR --trellis2-model-path $TRELLIS2_MODEL_ID --trellis2-model-revision $TRELLIS2_MODEL_REVISION --trellis2-resolution $TRELLIS2_RESOLUTION --seed 42"
"$TRELLIS2_PYTHON" -m backend.benchmark.preflight_image_to_mesh_providers --command "$TRELLIS2_PREFLIGHT_COMMAND" --output "${TRELLIS2_PREFLIGHT_PATH:-/tmp/trellis2_provider_preflight.json}" --require-runnable
echo "TRELLIS.2 setup checkpoint: provider preflight passed"
if [[ "${TRELLIS2_PREFETCH:-1}" == "1" ]]; then
  "$TRELLIS2_PYTHON" -m backend.benchmark.run_image_to_mesh_provider --provider trellis2 --provider-dir "$TRELLIS2_DIR" --trellis2-model-path "$TRELLIS2_MODEL_ID" --trellis2-model-revision "$TRELLIS2_MODEL_REVISION" --trellis2-resolution "$TRELLIS2_RESOLUTION" --seed 42 --timeout 3600 --prefetch-only
  echo "TRELLIS.2 setup checkpoint: pinned model prefetched"
fi
if [[ "$TRELLIS2_HAD_ATTN_BACKEND" == "x" ]]; then
  export ATTN_BACKEND="$TRELLIS2_PREVIOUS_ATTN_BACKEND"
else
  unset ATTN_BACKEND
fi
if [[ "$TRELLIS2_HAD_SPARSE_ATTN_BACKEND" == "x" ]]; then
  export SPARSE_ATTN_BACKEND="$TRELLIS2_PREVIOUS_SPARSE_ATTN_BACKEND"
else
  unset SPARSE_ATTN_BACKEND
fi
echo "TRELLIS.2 setup checkpoint: caller attention environment restored"
python - <<'PY' > "$PREFLIGHT_PATH"
import json, os, pathlib, subprocess
archive = pathlib.Path(os.environ['ARCHIVE_PATH'])
manifest = pathlib.Path(os.environ['MANIFEST_PATH'])
payload = {
    'archive': str(archive),
    'archive_sha256': subprocess.check_output(['sha256sum', str(archive)], text=True).split()[0],
    'repo_dir': os.environ['REPO_DIR'],
    'repo_remote': os.environ['REPO_REMOTE'],
    'repo_ref': os.environ['REPO_REF'],
    'resolved_commit': subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip(),
    'extract_root': os.environ['EXTRACT_ROOT'],
    'gpu_preflight': os.environ['GPU_PREFLIGHT_PATH'],
    'trellis2_provider_preflight': os.environ['TRELLIS2_PREFLIGHT_PATH'],
    'hunyuan3d_2mv_provider_preflight': os.environ['HUNYUAN3D_2MV_PREFLIGHT_PATH'],
    'manifest': str(manifest),
    'manifest_rows': sum(1 for line in manifest.read_text().splitlines() if line.strip()),
}
if os.environ.get('LORA_PATH'):
    payload['lora_path'] = os.environ['LORA_PATH']
    payload['lora_adapter'] = os.environ['LORA_ADAPTER_PATH']
print(json.dumps(payload, indent=2, sort_keys=True))
PY
if [[ "${COLAB_PROVIDER_SETUP_ONLY:-0}" == "1" || "${HUNYUAN3D_SETUP_ONLY:-0}" == "1" || "${HUNYUAN3D_2MV_SETUP_ONLY:-0}" == "1" || "${TRIPOSR_SETUP_ONLY:-0}" == "1" || "${TRIPOSG_SETUP_ONLY:-0}" == "1" || "${PIXAL3D_SETUP_ONLY:-0}" == "1" || "${TRELLIS2_SETUP_ONLY:-0}" == "1" ]]; then
  echo "Provider setup only requested; skipping benchmark stages"
  exit 0
fi
python -u -m backend.benchmark.colab_g4_orchestrator --use-current-repo --run-name g4_stl_first_trellis2_component_close_s40_n5 --stage cache --stage eval --stage combine --manifest /content/3dprintpic_colab_inputs/inputs/manifest.jsonl --eval-limit 5 --score-profile stl-quality --cache-download-mode snapshot --cache-max-workers 8 --min-paired-n 5 --max-method-failures 5 --modern-config backend/benchmark/experiment_configs/modelnet10_60_balanced_stl_quality_trellis2_component_close_s40_n5.json --skip-cache --depth-provider depth-anything-v2 --depth-model depth-anything/Depth-Anything-V2-Small-hf --stl-target-dimension 96 --candidate-method trellis2_biharmonic_prefill_component_close_d995_no_hull_stl_inferred_bbox_direct_mesh --current-method triposg_biharmonic_prefill_repaired_stl_inferred_bbox_direct_mesh --eval-start 0 --require-modern-cache --require-image-to-mesh-providers --allow-missing-split-audit --contact-sheet-methods masked,mirror,triposg_biharmonic_prefill_repaired_stl_inferred_bbox_direct_mesh,trellis2_biharmonic_prefill_raw_direct_mesh,trellis2_biharmonic_prefill_repaired_stl_inferred_bbox_direct_mesh,trellis2_biharmonic_prefill_component_close_d995_no_hull_stl_inferred_bbox_direct_mesh --contact-sheet-max-samples 5
) 2>&1 | tee "$RUN_LOG"
run_status="${PIPESTATUS[0]}"
set -e
export RUN_STATUS="$run_status"
cd "$REPO_DIR"
python - <<'PY'
from datetime import datetime, timezone
import csv, json, os, pathlib, subprocess, sys, tarfile
from backend.benchmark.package_colab_inputs import build_compact_results_archive

def add_if_exists(tar: tarfile.TarFile, path: pathlib.Path, arcname: str) -> None:
    if path.exists():
        tar.add(path, arcname=arcname)

def read_csv_rows(path: pathlib.Path) -> list[dict]:
    if not path.exists():
        return []
    with path.open(newline='', encoding='utf-8') as csv_file:
        return list(csv.DictReader(csv_file))

def read_json_object(path: pathlib.Path) -> dict:
    if not path.exists():
        return {}
    try:
        return json.loads(path.read_text(encoding='utf-8'))
    except Exception as exc:
        return {'read_error': f'{type(exc).__name__}: {exc}'}

def summarize_gpu_preflight(path: pathlib.Path) -> dict:
    data = read_json_object(path)
    summary = {'exists': path.exists(), 'path': str(path)}
    if not data:
        return summary
    if data.get('read_error'):
        summary['read_error'] = data.get('read_error')
        return summary
    summary.update(
        {
            'ok': data.get('ok'),
            'guard_requested': data.get('guard_requested'),
            'requirements': data.get('requirements') or {},
            'nvidia_smi_available': data.get('nvidia_smi_available'),
            'nvidia_smi_error': data.get('nvidia_smi_error', ''),
            'errors': data.get('errors') or [],
            'gpus': data.get('gpus') or [],
            'eligible_gpus': data.get('eligible_gpus') or [],
        }
    )
    return summary

def compact_methods(rows: list[dict]) -> list[dict]:
    keys = [
        'method', 'base_method', 'stl_mode', 'n', 'attempted_n', 'success_rate',
        'error_count', 'logged_failure_count', 'rank_score',
        'mesh_surface_chamfer_l1_median', 'mesh_surface_hausdorff95_median',
        'provider_inference_runtime_seconds_median', 'provider_invocation_runtime_seconds_median',
        'direct_mesh_command_runtime_seconds_median', 'repair_runtime_seconds_median',
        'mesh_postprocess_runtime_seconds_median', 'provider_peak_cuda_vram_gib_median',
        'repair_total_runtime_seconds_median', 'repair_diagnostic_runtime_seconds_median',
        'repair_component_filter_input_components_mean',
        'repair_component_filter_output_components_mean',
        'repair_component_filter_input_faces_median',
        'repair_component_filter_output_faces_median',
        'repair_component_filter_removed_area_ratio_median',
        'repair_bounded_hole_fill_boundary_loops_median',
        'repair_bounded_hole_fill_eligible_loops_median',
        'repair_bounded_hole_fill_estimated_faces_median',
        'repair_bounded_hole_fill_face_budget_median',
        'repair_bounded_hole_fill_faces_added_median',
        'repair_bounded_hole_fill_watertight_mean',
        'repair_simplification_requested_target_faces_median',
        'repair_simplification_reserved_hole_faces_median',
        'repair_simplification_target_faces_median',
        'repair_simplification_applied_mean',
        'repair_simplification_audit_available_mean',
        'repair_simplification_audit_runtime_seconds_median',
        'repair_simplification_volume_relative_change_abs_median',
        'repair_simplification_bbox_extent_relative_change_max_median',
        'repair_simplification_bounds_center_shift_normalized_median',
        'repair_simplification_surface_chamfer_l1_normalized_median',
        'repair_simplification_surface_hausdorff95_normalized_median',
        'repair_preclean_printable_mean', 'repair_preclean_retriangulation_attempted_mean',
        'repair_preclean_retriangulation_accepted_mean',
        'repair_preclean_retriangulated_printable_mean',
        'repair_preclean_retriangulated_geometry_preserved_mean',
        'repair_preclean_retriangulated_face_count_relative_change_abs_median',
        'repair_preclean_retriangulated_vertex_count_relative_change_abs_median',
        'repair_preclean_retriangulated_volume_relative_change_abs_median',
        'repair_preclean_retriangulated_bbox_extent_relative_change_max_median',
        'repair_preclean_retriangulated_bounds_center_shift_normalized_median',
        'repair_preclean_retriangulated_vertex_displacement_max_normalized_median',
        'repair_preclean_retriangulated_surface_chamfer_l1_normalized_median',
        'repair_preclean_retriangulated_surface_hausdorff95_normalized_median',
        'repair_cleaning_skipped_mean',
        'repair_cleaned_printable_mean',
        'heldout_view_silhouette_iou_mean_median', 'heldout_view_silhouette_iou_min_median',
        'raw_mesh_volume_fill_ratio_median', 'stl_volume_fill_ratio_median',
        'repair_volume_fill_ratio_relative_change_median',
        'repair_volume_fill_ratio_relative_change_abs_median',
        'repair_convex_hull_used_mean',
        'silhouette_iou_masked_median', 'stl_exists_median', 'stl_is_watertight_median',
        'stl_is_volume_median', 'stl_is_manifold_median', 'stl_positive_volume_median',
        'stl_single_component_median', 'stl_nonmanifold_edge_count_log1p_median',
        'stl_degenerate_face_ratio_median', 'stl_component_excess_log1p_median',
        'stl_bbox_aspect_ratio_median', 'stl_faces_per_normalized_bbox_volume_log1p_median',
        'stl_faces_per_bbox_volume_log1p_median',
    ]
    return [{key: row.get(key, '') for key in keys if key in row} for row in rows]

def summarize_benchmark_dir(path: pathlib.Path) -> dict:
    aggregate = path / 'aggregate_summary.csv'
    ranked = path / 'ranked_experiments.csv'
    selection = path / 'selection_decision.json'
    contact_sheet = path / 'artifact_contact_sheet.png'
    image_to_mesh_preflight = path / 'image_to_mesh_provider_preflight.json'
    aggregate_rows = read_csv_rows(aggregate)
    ranked_rows = read_csv_rows(ranked)
    selection_json = read_json_object(selection)
    image_to_mesh_preflight_json = read_json_object(image_to_mesh_preflight)
    digest = {
        'path': str(path),
        'aggregate_summary_exists': aggregate.exists(),
        'ranked_experiments_exists': ranked.exists(),
        'selection_decision_exists': selection.exists(),
        'contact_sheet_exists': contact_sheet.exists(),
        'image_to_mesh_provider_preflight_exists': image_to_mesh_preflight.exists(),
        'methods': compact_methods(ranked_rows or aggregate_rows),
    }
    if image_to_mesh_preflight_json:
        rows = image_to_mesh_preflight_json.get('rows') or []
        digest['image_to_mesh_provider_readiness'] = [
            {
                'provider': row.get('provider', ''),
                'readiness': row.get('readiness', ''),
                'runnable': row.get('runnable', False),
                'experiment_names': row.get('experiment_names', []),
                'setup_errors': row.get('setup_errors', []),
            }
            for row in rows
        ]
    if ranked_rows:
        top = ranked_rows[0]
        digest['top_method'] = top.get('method', '')
        digest['top_rank_score'] = top.get('rank_score', '')
    if selection_json:
        digest['decision'] = selection_json.get('decision', '')
        digest['candidate_method'] = selection_json.get('candidate_method', '')
        digest['failed_checks'] = [check.get('name', '') for check in selection_json.get('failed_checks', [])]
    return digest

def run_stl_ingest_report(output_root: pathlib.Path, ingest_dir: pathlib.Path, json_path: pathlib.Path, md_path: pathlib.Path, gpu_preflight_summary: dict) -> dict:
    log_path = ingest_dir / 'stl_first_ingest.log'
    result = {
        'status': 'skipped',
        'output_dir': str(ingest_dir),
        'json': str(json_path),
        'markdown': str(md_path),
        'log': str(log_path),
    }
    if os.environ.get('COLAB_PROVIDER_SETUP_ONLY') == '1' or os.environ.get('HUNYUAN3D_SETUP_ONLY') == '1' or os.environ.get('HUNYUAN3D_2MV_SETUP_ONLY') == '1' or os.environ.get('TRIPOSR_SETUP_ONLY') == '1' or os.environ.get('TRIPOSG_SETUP_ONLY') == '1' or os.environ.get('PIXAL3D_SETUP_ONLY') == '1' or os.environ.get('TRELLIS2_SETUP_ONLY') == '1':
        result['reason'] = 'provider_setup_only'
        return result
    if not output_root.exists():
        result['reason'] = 'gpu_preflight_failed' if gpu_preflight_summary.get('ok') is False else 'output_root_missing'
        if gpu_preflight_summary.get('errors'):
            result['gpu_preflight_errors'] = gpu_preflight_summary.get('errors')
        return result
    ingest_dir.mkdir(parents=True, exist_ok=True)
    cmd = [
        sys.executable,
        '-m',
        'backend.benchmark.ingest_stl_results',
        f"{os.environ['RUN_NAME']}={output_root}",
        '--output-dir',
        str(ingest_dir),
        '--output-json',
        str(json_path),
        '--output-md',
        str(md_path),
        '--score-profile',
        'stl-quality',
        '--score-mode',
        'baseline-delta',
        '--baseline-method',
        'masked',
    ]
    with log_path.open('w', encoding='utf-8') as log_file:
        completed = subprocess.run(cmd, cwd=os.environ['REPO_DIR'], stdout=log_file, stderr=subprocess.STDOUT, text=True, check=False)
    result['status'] = 'ok' if completed.returncode == 0 else 'failed'
    result['returncode'] = completed.returncode
    result['json_exists'] = json_path.exists()
    result['markdown_exists'] = md_path.exists()
    if json_path.exists():
        try:
            report = json.loads(json_path.read_text(encoding='utf-8'))
            runs = report.get('runs') or []
            if runs:
                decision = runs[0].get('architecture_replacement_decision') or {}
                result['architecture_replacement_decision'] = {
                    'decision': decision.get('decision', ''),
                    'recommended_method': decision.get('recommended_method', ''),
                    'recommended_stl_mode': decision.get('recommended_stl_mode', ''),
                    'score_delta_vs_depth_relief': decision.get('score_delta_vs_depth_relief'),
                    'depth_relief_baseline_method': (decision.get('depth_relief_baseline') or {}).get('method', ''),
                    'promotion_eligible_challenger_method': (decision.get('promotion_eligible_challenger') or {}).get('method', ''),
                    'score_leading_challenger_method': (decision.get('score_leading_challenger') or {}).get('method', ''),
                }
                result['run_count'] = len(runs)
        except Exception as exc:
            result['report_read_error'] = f'{type(exc).__name__}: {exc}'
    return result

output_root = pathlib.Path(os.environ['OUTPUT_ROOT'])
run_log = pathlib.Path(os.environ['RUN_LOG'])
gpu_preflight = pathlib.Path(os.environ['GPU_PREFLIGHT_PATH'])
preflight = pathlib.Path(os.environ['PREFLIGHT_PATH'])
trellis2_preflight = pathlib.Path(os.environ['TRELLIS2_PREFLIGHT_PATH'])
hunyuan3d_2mv_preflight = pathlib.Path(os.environ['HUNYUAN3D_2MV_PREFLIGHT_PATH'])
summary_path = pathlib.Path(os.environ['RESULTS_SUMMARY'])
archive_path = pathlib.Path(os.environ['RESULTS_ARCHIVE'])
compact_archive_path = pathlib.Path(os.environ['RESULTS_COMPACT_ARCHIVE'])
stl_ingest_dir = pathlib.Path(os.environ['STL_INGEST_DIR'])
stl_ingest_json = pathlib.Path(os.environ['STL_INGEST_JSON'])
stl_ingest_md = pathlib.Path(os.environ['STL_INGEST_MD'])
run_status = int(os.environ['RUN_STATUS'])
gpu_preflight_summary = summarize_gpu_preflight(gpu_preflight)
trellis2_preflight_summary = read_json_object(trellis2_preflight)
trellis2_preflight_failed = any(not row.get('runnable') for row in trellis2_preflight_summary.get('rows', []))
hunyuan3d_2mv_preflight_expected = False
hunyuan3d_2mv_preflight_summary = read_json_object(hunyuan3d_2mv_preflight)
hunyuan3d_2mv_preflight_rows = hunyuan3d_2mv_preflight_summary.get('rows', [])
hunyuan3d_2mv_preflight_failed = hunyuan3d_2mv_preflight_expected and (not hunyuan3d_2mv_preflight_rows or any(not row.get('runnable') for row in hunyuan3d_2mv_preflight_rows))
orchestrator_result = output_root / 'orchestrator_result.json'
selection_decisions = sorted(output_root.glob('combined/*/selection_decision.json')) if output_root.exists() else []
eval_summaries = [summarize_benchmark_dir(path) for path in sorted(output_root.glob('experiments/*'))] if output_root.exists() else []
combined_summaries = [summarize_benchmark_dir(path) for path in sorted(output_root.glob('combined/*'))] if output_root.exists() else []
stl_ingest_report = run_stl_ingest_report(output_root, stl_ingest_dir, stl_ingest_json, stl_ingest_md, gpu_preflight_summary)
summary = {
    'generated_at': datetime.now(timezone.utc).isoformat(timespec='seconds'),
    'run_name': os.environ['RUN_NAME'],
    'run_status': run_status,
    'failure_stage': 'gpu_preflight' if run_status and gpu_preflight_summary.get('ok') is False else ('hunyuan3d_2mv_preflight' if run_status and hunyuan3d_2mv_preflight_failed else ('trellis2_preflight' if run_status and trellis2_preflight_failed else '')),
    'provider_setup_only': os.environ.get('COLAB_PROVIDER_SETUP_ONLY') == '1' or os.environ.get('HUNYUAN3D_SETUP_ONLY') == '1' or os.environ.get('HUNYUAN3D_2MV_SETUP_ONLY') == '1' or os.environ.get('TRIPOSR_SETUP_ONLY') == '1' or os.environ.get('TRIPOSG_SETUP_ONLY') == '1' or os.environ.get('PIXAL3D_SETUP_ONLY') == '1' or os.environ.get('TRELLIS2_SETUP_ONLY') == '1',
    'output_root': str(output_root),
    'output_root_exists': output_root.exists(),
    'run_log': str(run_log),
    'gpu_preflight': str(gpu_preflight),
    'gpu_preflight_summary': gpu_preflight_summary,
    'preflight': str(preflight),
    'trellis2_provider_preflight': str(trellis2_preflight),
    'trellis2_provider_preflight_summary': trellis2_preflight_summary,
    'hunyuan3d_2mv_provider_preflight': str(hunyuan3d_2mv_preflight),
    'hunyuan3d_2mv_provider_preflight_expected': hunyuan3d_2mv_preflight_expected,
    'hunyuan3d_2mv_provider_preflight_summary': hunyuan3d_2mv_preflight_summary,
    'results_archive': str(archive_path),
    'results_compact_archive': str(compact_archive_path),
    'stl_first_ingest_report': stl_ingest_report,
    'orchestrator_result': str(orchestrator_result) if orchestrator_result.exists() else '',
    'selection_decisions': [str(path) for path in selection_decisions],
    'eval_summaries': eval_summaries,
    'combined_summaries': combined_summaries,
}
summary_path.write_text(json.dumps(summary, indent=2, sort_keys=True) + '\n', encoding='utf-8')
build_compact_results_archive(
    output_root=output_root,
    archive_path=compact_archive_path,
    extra_files=[
        (gpu_preflight, 'gpu_preflight.json'),
        (preflight, 'launch_preflight.json'),
        (trellis2_preflight, 'trellis2_provider_preflight.json'),
        (hunyuan3d_2mv_preflight, 'hunyuan3d_2mv_provider_preflight.json'),
        (run_log, 'run_colab_eval.log'),
        (summary_path, 'results_summary.json'),
        (stl_ingest_json, 'stl_first_ingest_report.json'),
        (stl_ingest_md, 'stl_first_ingest_report.md'),
        (stl_ingest_dir / 'stl_first_ingest.log', 'stl_first_ingest.log'),
    ],
)
archive_path.parent.mkdir(parents=True, exist_ok=True)
with tarfile.open(archive_path, 'w:gz') as tar:
    add_if_exists(tar, gpu_preflight, 'gpu_preflight.json')
    add_if_exists(tar, preflight, 'launch_preflight.json')
    add_if_exists(tar, trellis2_preflight, 'trellis2_provider_preflight.json')
    add_if_exists(tar, hunyuan3d_2mv_preflight, 'hunyuan3d_2mv_provider_preflight.json')
    add_if_exists(tar, run_log, 'run_colab_eval.log')
    add_if_exists(tar, summary_path, 'results_summary.json')
    add_if_exists(tar, stl_ingest_json, 'stl_first_ingest_report.json')
    add_if_exists(tar, stl_ingest_md, 'stl_first_ingest_report.md')
    add_if_exists(tar, stl_ingest_dir / 'stl_first_ingest.log', 'stl_first_ingest.log')
    if output_root.exists():
        tar.add(output_root, arcname=f"output/{output_root.name}")
print(json.dumps(summary, indent=2, sort_keys=True))
PY
echo "Compact results archive: $RESULTS_COMPACT_ARCHIVE"
echo "Results archive: $RESULTS_ARCHIVE"
exit "$run_status"
